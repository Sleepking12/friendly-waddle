/*******************************************************************************
 * 文件名：main_灯闪烁验证.c
 * 用途  ：验证 DAPLink 下载的程序到底跑没跑（纯寄存器，不用串口、不用 HAL）
 * 芯片  ：STM32F103C8T6
 *
 * 【现象】
 *   板载 PC13 灯（低电平点亮）每 200ms 闪一次：
 *       亮 200ms → 灭 200ms → 亮 200ms → ...
 *   闪得比较快，很显眼。
 *
 *   同时 PA4、PB5、PC14 也跟着一起闪（如果面包板上有 LED 就能看到）
 *
 * 【判断】
 *   ┌──────────────────┬────────────────────────────────┐
 *   │ PC13 灯快速闪    │ 程序在跑 → DAPLink 通道没问题  │
 *   │ PC13 灯不闪      │ 程序没跑，或板子没这个灯       │
 *   └──────────────────┴────────────────────────────────┘
 ******************************************************************************/

#include "stm32f1xx_hal.h"

void Error_Handler(void);

/* 寄存器地址 */
#define RCC_APB2ENR     (*(volatile uint32_t *)0x40021018)
#define GPIOA_CRL       (*(volatile uint32_t *)0x40010800)
#define GPIOA_CRH       (*(volatile uint32_t *)0x40010804)
#define GPIOA_ODR       (*(volatile uint32_t *)0x4001080C)
#define GPIOB_CRL       (*(volatile uint32_t *)0x40010C00)
#define GPIOB_ODR       (*(volatile uint32_t *)0x40010C0C)
#define GPIOC_CRH       (*(volatile uint32_t *)0x40011004)
#define GPIOC_ODR       (*(volatile uint32_t *)0x4001100C)

/* SysTick 寄存器 */
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

/*==============================================================================
 * 毫秒延时（SysTick 轮询，不依赖中断）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U)
        {
            ;
        }
        SYSTICK_CTRL = 0x00000000U;
    }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        ;
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    /*---- 1) 开 GPIOA/B/C 时钟 ----*/
    RCC_APB2ENR |= (1U << 2) | (1U << 3) | (1U << 4);

    /*---- 2) 把 4 个 LED 引脚配成通用推挽输出（2MHz）----
     * 4 位一个引脚：CNF=00 MODE=10（2MHz）→ 0010 = 0x2
     */
    GPIOA_CRL &= ~(0xFU << 16);  GPIOA_CRL |= (0x2U << 16);   /* PA4  */
    GPIOB_CRL &= ~(0xFU << 20);  GPIOB_CRL |= (0x2U << 20);   /* PB5  */
    GPIOC_CRH &= ~(0xFU << 24);  GPIOC_CRH |= (0x2U << 24);   /* PC14 */
    GPIOC_CRH &= ~(0xFU << 20);  GPIOC_CRH |= (0x2U << 20);   /* PC13 */

    /*---- 3) 先全部熄灭（低电平点亮 → 高电平为灭）----*/
    GPIOA_ODR |=  (1U << 4);
    GPIOB_ODR |=  (1U << 5);
    GPIOC_ODR |=  (1U << 14);
    GPIOC_ODR |=  (1U << 13);

    /*---- 4) 死循环：全部引脚一起快速闪烁 ----*/
    while (1)
    {
        /* 全部点亮（输出低电平）*/
        GPIOA_ODR &= ~(1U << 4);
        GPIOB_ODR &= ~(1U << 5);
        GPIOC_ODR &= ~(1U << 14);
        GPIOC_ODR &= ~(1U << 13);

        Delay_ms(200);

        /* 全部熄灭（输出高电平）*/
        GPIOA_ODR |=  (1U << 4);
        GPIOB_ODR |=  (1U << 5);
        GPIOC_ODR |=  (1U << 14);
        GPIOC_ODR |=  (1U << 13);

        Delay_ms(200);
    }
}
