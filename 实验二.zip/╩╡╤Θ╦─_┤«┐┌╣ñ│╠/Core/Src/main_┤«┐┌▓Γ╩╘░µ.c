/*******************************************************************************
 * 文件名：main_串口测试版.c
 * 用途  ：串口通信故障诊断专用
 * 芯片  ：STM32F103C8T6
 *
 * 【这个程序做什么】
 *   ① 每 500ms 翻转一次 PA9（USART1_TX 引脚）
 *      → 用万用表量 PA9，电压会在 0V/3.3V 之间**规律跳动**
 *      → 如果跳动，说明引脚是活的、接线通的
 *
 *   ② 板载 LED（PC13）每 500ms 闪一次
 *      → 一眼看出程序在跑（不闪就是程序没运行）
 *
 *   ③ 用串口每 1 秒发送一行 "TEST 1234567890"
 *      → 串口助手应该收到
 *
 *   ④ 收到任何字符都原样回显
 *      → 验证 USART1_RX 通不通
 *
 * 【怎么用这个程序判断故障】
 *
 *   ┌────────────────────┬──────────────────────────────────┐
 *   │ 现象               │ 结论                             │
 *   ├────────────────────┼──────────────────────────────────┤
 *   │ LED 不闪           │ 程序没运行（下载失败/芯片问题）  │
 *   │ LED 闪，PA9 不跳   │ 引脚配置有问题                   │
 *   │ PA9 跳，串口没数据 │ CH340 或串口助手的问题           │
 *   │ 串口收到数据       │ 串口链路正常 ✅                  │
 *   │ 发字符能回显       │ 收发都正常 ✅                    │
 *   └────────────────────┴──────────────────────────────────┘
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include <string.h>

void Error_Handler(void);

#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

/* SysTick 寄存器（延时用，不依赖中断）*/
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时（SysTick 轮询，不依赖中断）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U)
        {
            ;
        }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * 系统时钟：内部 HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U)
    {
        ;
    }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI)
    {
        ;
    }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        ;
    }
}

/*==============================================================================
 * USART1 底层初始化 + 顺便把 PC13 配成 LED 输出
 *============================================================================*/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();
        __HAL_RCC_GPIOC_CLK_ENABLE();

        /* PA9 = USART1_TX：复用推挽输出 */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* PA10 = USART1_RX：上拉输入 */
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* PC13 = 板载 LED（低电平点亮），配成推挽输出 */
        GPIO_InitStruct.Pin   = GPIO_PIN_13;
        GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull  = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   /* 先熄灭 */
    }
}

static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    uint8_t rx = 0;
    uint8_t tx = 0;

    HAL_Init();
    SystemClock_Config();
    MX_USART1_UART_Init();

    while (1)
    {
        /*---- ① 发送一行测试数据 ----*/
        HAL_UART_Transmit(&huart1, (uint8_t *)"TEST 1234567890\r\n", 17, UART_TIMEOUT);

        /*---- ② 板载 LED 闪一下（证明程序在跑）----*/
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);   /* 亮 */
        Delay_ms(500);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);     /* 灭 */

        /*---- ③ 收一个字符就原样回显（验证接收）----*/
        if (HAL_UART_Receive(&huart1, &rx, 1, 400U) == HAL_OK)
        {
            tx = rx;
            HAL_UART_Transmit(&huart1, &tx, 1, UART_TIMEOUT);
            HAL_UART_Transmit(&huart1, (uint8_t *)" <-- 收到\r\n", 12, UART_TIMEOUT);
        }

        /*---- ④ 每 100ms 翻转一次 PA9（万用表能看出跳动）----
         * 注意：这会干扰串口数据，所以只在没有串口助手时观察。
         * 想看 PA9 跳动就把下面两行的注释去掉，同时把上面的发送注释掉。
         */
        /* HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET); */
        /* Delay_ms(100); */
        /* HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET);   */
        /* Delay_ms(100); */
    }
}
