/*******************************************************************************
 * 文件名：main.c
 * 最小测试：只用寄存器让 PC13 灯慢闪（不调任何库、不初始化任何外设）
 * 芯片  ：STM32F103C8T6
 *
 * 现象：PC13 灯 亮 1 秒 → 灭 1 秒 → 亮 1 秒 …… 无限循环
 *
 * 这个程序刻意做到最简：
 *   - 不调用 HAL_Init()
 *   - 不配置系统时钟
 *   - 不初始化串口
 *   - 只有一个主循环 + SysTick 轮询延时
 *
 * 如果连这个灯都不规律闪，那 100% 是硬件问题（供电/复位电路/芯片）。
 ******************************************************************************/

/* 寄存器地址（直接用地址，不包含任何头文件以外的依赖）*/
#define RCC_APB2ENR     (*(volatile unsigned int *)0x40021018)
#define GPIOC_CRH       (*(volatile unsigned int *)0x40011004)
#define GPIOC_ODR       (*(volatile unsigned int *)0x4001100C)

#define SYSTICK_CTRL    (*(volatile unsigned int *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile unsigned int *)0xE000E014)
#define SYSTICK_VAL     (*(volatile unsigned int *)0xE000E018)

/*==============================================================================
 * 毫秒延时（SysTick 轮询）
 *============================================================================*/
static void Delay_ms(unsigned int ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    unsigned int i;

    /* 1) 开 GPIOC 时钟 */
    RCC_APB2ENR |= (1U << 4);

    /* 2) PC13 配成通用推挽输出 2MHz */
    GPIOC_CRH &= ~(0xFU << 20);
    GPIOC_CRH |=  (0x2U << 20);

    /* 3) 先熄灭 */
    GPIOC_ODR |= (1U << 13);

    /*--- 第 1 阶段：快闪 20 次（表示程序启动）---*/
    for (i = 0; i < 20U; i++)
    {
        GPIOC_ODR &= ~(1U << 13);   /* 亮 */
        Delay_ms(100);
        GPIOC_ODR |=  (1U << 13);   /* 灭 */
        Delay_ms(100);
    }

    /*--- 第 2 阶段：慢闪（1 秒亮 / 1 秒灭），无限循环 ---*/
    while (1)
    {
        GPIOC_ODR &= ~(1U << 13);   /* 亮 */
        Delay_ms(1000);
        GPIOC_ODR |=  (1U << 13);   /* 灭 */
        Delay_ms(1000);
    }
}
