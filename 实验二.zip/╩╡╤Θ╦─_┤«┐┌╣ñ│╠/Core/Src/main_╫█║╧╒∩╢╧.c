/*******************************************************************************
 * 文件名：main_综合诊断.c
 * 用途  ：PC13 灯 + 串口同时工作，一次判断两个问题
 * 芯片  ：STM32F103C8T6
 *
 * 【现象】
 *   ① 板载 PC13 灯：快闪 3 次（表示程序启动成功）
 *   ② 然后每秒发一行串口 "U0001 OK" 之类的数据
 *   ③ PC13 灯在每次发送时同时闪烁一下
 *
 * 【判断】
 *   ┌────────────────────┬──────────────────────────────────┐
 *   │ 现象               │ 结论                             │
 *   ├────────────────────┼──────────────────────────────────┤
 *   │ 灯快闪 3 次        │ 程序启动成功                     │
 *   │ 灯一直慢闪 + 串口有 │ 全部正常 ✅                      │
 *   │ 灯一直慢闪但串口没 │ USART 发送有问题                 │
 *   │ 灯完全不闪         │ 程序没跑 / HAL_Init 卡住         │
 *   └────────────────────┴──────────────────────────────────┘
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include <string.h>

void Error_Handler(void);

#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

/* 寄存器直接操作（不经过 HAL，保证一定有效）*/
#define RCC_APB2ENR     (*(volatile uint32_t *)0x40021018)
#define GPIOC_CRH       (*(volatile uint32_t *)0x40011004)
#define GPIOC_ODR       (*(volatile uint32_t *)0x4001100C)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时（SysTick 轮询）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * PC13 灯控制（直接写寄存器，绕开 HAL）
 *============================================================================*/
static void PC13_On(void)   { GPIOC_ODR &= ~(1U << 13); }
static void PC13_Off(void)  { GPIOC_ODR |=  (1U << 13); }

/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * 初始化（不用 HAL_Init，手动配 PC13）
 *============================================================================*/
static void PC13_Init(void)
{
    /* 开 GPIOC 时钟 */
    RCC_APB2ENR |= (1U << 4);

    /* PC13 配成通用推挽输出 2MHz：CNF=00 MODE=10 → 0x2 */
    GPIOC_CRH &= ~(0xFU << 20);
    GPIOC_CRH |=  (0x2U << 20);

    PC13_Off();     /* 先熄灭 */
}

static void USART1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA9 = USART1_TX */
    GPIO_InitStruct.Pin   = GPIO_PIN_9;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    uint32_t n = 1;
    char line[16];
    uint32_t k;

    /*---- 第 1 步：先闪 PC13 灯 3 次（不依赖任何库，纯寄存器）----
     * 如果灯会闪，说明芯片在跑这段代码
     */
    PC13_Init();
    for (k = 0; k < 3U; k++)
    {
        PC13_On();
        Delay_ms(150);
        PC13_Off();
        Delay_ms(150);
    }

    /*---- 第 2 步：初始化串口 ----*/
    HAL_Init();
    SystemClock_Config();
    USART1_Init();

    /*---- 第 3 步：主循环：发串口 + 灯闪 ----*/
    while (1)
    {
        line[0] = 'U';
        line[1] = (char)('0' + (n / 1000U) % 10U);
        line[2] = (char)('0' + (n / 100U) % 10U);
        line[3] = (char)('0' + (n / 10U) % 10U);
        line[4] = (char)('0' + (n % 10U));
        line[5] = ' ';
        line[6] = 'O';
        line[7] = 'K';
        line[8] = '\r';
        line[9] = '\n';

        PC13_On();                                    /* 发送时灯亮 */
        HAL_UART_Transmit(&huart1, (uint8_t *)line, 10, UART_TIMEOUT);
        PC13_Off();                                   /* 发送完灯灭 */

        n++;
        if (n > 9999U) { n = 1U; }

        Delay_ms(1000);
    }
}
