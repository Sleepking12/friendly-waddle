/*******************************************************************************
 * 文件名：main_复位原因诊断.c
 * 用途  ：查出芯片为什么反复复位
 * 芯片  ：STM32F103C8T6
 *
 * 【原理】
 *   RCC_CSR 寄存器会记录上一次复位的原因：
 *     bit31 LPWRRSTF  低功耗管理复位
 *     bit30 WWDGRSTF  窗口看门狗复位
 *     bit29 IWDGRSTF  独立看门狗复位   ← 最常见！
 *     bit28 SFTRSTF   软件复位
 *     bit27 PORRSTF   上电/掉电复位
 *     bit26 PINRSTF   外部复位（NRST 引脚）
 *
 *   程序开机就把这些标志发到串口，我们就能知道是什么在复位它。
 *
 * 【现象】
 *   每秒发两行：
 *     RST: xxxxxxxx        ← 复位标志（十六进制）
 *     N=00001 OK           ← 计数（如果一直不涨说明在复位）
 ******************************************************************************/

#include "stm32f1xx_hal.h"

void Error_Handler(void);

#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

/* 寄存器直接操作 */
#define RCC_APB2ENR     (*(volatile uint32_t *)0x40021018)
#define RCC_CSR         (*(volatile uint32_t *)0x40021024)   /* 复位原因 */
#define RCC_APB1ENR     (*(volatile uint32_t *)0x4002101C)
#define GPIOC_CRH       (*(volatile uint32_t *)0x40011004)
#define GPIOC_ODR       (*(volatile uint32_t *)0x4001100C)

#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

/* 备份寄存器（复位不清除，用来验证是否真的复位了）*/
#define BKP_DR1         (*(volatile uint16_t *)0x40006C04)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * 系统时钟
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

static void USART1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin   = GPIO_PIN_9;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    uint32_t rstFlags;
    uint32_t n = 1;
    uint16_t bootCount;
    char buf[48];
    uint32_t i;
    const char hexdig[] = "0123456789ABCDEF";

    /*---- 先读复位标志 + 备份寄存器（越早读越准）----*/
    rstFlags = RCC_CSR;

    /* 备份寄存器：复位不清除。用它数"这是第几次启动" */
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_RCC_BKP_CLK_ENABLE();
    HAL_PWR_EnableBkUpAccess();
    bootCount = BKP_DR1;
    if (bootCount > 9000U) { bootCount = 0U; }   /* 首次上电随机值 */
    bootCount++;
    BKP_DR1 = bootCount;

    /* 清复位标志 */
    RCC_CSR |= (1U << 24);      /* RMVF */

    /*---- 初始化 ----*/
    HAL_Init();
    SystemClock_Config();
    USART1_Init();

    /*---- 开机发诊断信息 ----*/
    for (i = 0; i < 3U; i++)
    {
        /* "RST: 0xXXXXXXXX\r\n" */
        buf[0]='R'; buf[1]='S'; buf[2]='T'; buf[3]=':'; buf[4]=' ';
        buf[5]='0'; buf[6]='x';
        for (uint32_t k = 0; k < 8U; k++)
        {
            buf[7 + k] = hexdig[(rstFlags >> ((7U - k) * 4U)) & 0xFU];
        }
        buf[15]='\r'; buf[16]='\n';
        HAL_UART_Transmit(&huart1, (uint8_t *)buf, 17, UART_TIMEOUT);

        /* "BOOT nnnn\r\n" */
        buf[0]='B'; buf[1]='O'; buf[2]='O'; buf[3]='T'; buf[4]=' ';
        buf[5]=(char)('0'+(bootCount/1000U)%10U);
        buf[6]=(char)('0'+(bootCount/100U)%10U);
        buf[7]=(char)('0'+(bootCount/10U)%10U);
        buf[8]=(char)('0'+(bootCount%10U));
        buf[9]='\r'; buf[10]='\n';
        HAL_UART_Transmit(&huart1, (uint8_t *)buf, 11, UART_TIMEOUT);

        Delay_ms(300);
    }

    /*---- 主循环 ----*/
    while (1)
    {
        buf[0]='N'; buf[1]='=';
        buf[2]=(char)('0'+(n/10000U)%10U);
        buf[3]=(char)('0'+(n/1000U)%10U);
        buf[4]=(char)('0'+(n/100U)%10U);
        buf[5]=(char)('0'+(n/10U)%10U);
        buf[6]=(char)('0'+(n%10U));
        buf[7]=' '; buf[8]='O'; buf[9]='K';
        buf[10]='\r'; buf[11]='\n';
        HAL_UART_Transmit(&huart1, (uint8_t *)buf, 12, UART_TIMEOUT);

        n++;
        if (n > 99999U) { n = 1U; }

        Delay_ms(1000);
    }
}
