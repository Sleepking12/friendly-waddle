﻿/*******************************************************************************
 * 文件名：main_PA9翻转测试.c
 * 用途  ：完全不用串口，纯寄存器把 PA9 当普通 IO 翻转，验证引脚和接线
 * 芯片  ：STM32F103C8T6
 *
 * 【原理】
 *   PA9 平时是 USART1_TX（复用推挽输出）。这里把它配成**通用推挽输出**，
 *   就变成一个普通 IO 引脚，可以手动翻转。
 *
 *   程序每 500ms 翻转一次 PA9：
 *     - PA9 输出高 → 万用表量到 3.3V
 *     - PA9 输出低 → 万用表量到 0V
 *   于是万用表读数会在 0V / 3.3V 之间**每半秒跳一次**。
 *
 * 【判断】
 *   ┌──────────────────────┬────────────────────────────────┐
 *   │ 现象                 │ 结论                           │
 *   ├──────────────────────┼────────────────────────────────┤
 *   │ PA9 电压规律跳动     │ 引脚是活的、接线通的 → 问题在  │
 *   │                      │ USART 配置或 CH340             │
 *   │ PA9 电压一直不动     │ 程序没跑 / 引脚坏 / 量错脚     │
 *   └──────────────────────┴────────────────────────────────┘
 *
 * 【顺带】
 *   同时翻转 PA4、PB5、PC14（原来接 LED 的三个脚），
 *   如果板子上有灯接着，能看到它们轮流亮。
 ******************************************************************************/

#include "stm32f1xx_hal.h"

void Error_Handler(void);

/*---------------- 寄存器地址（直接用寄存器，不经过 HAL）----------------*/
#define RCC_APB2ENR     (*(volatile uint32_t *)0x40021018)   /* APB2 时钟使能 */

#define GPIOA_CRL       (*(volatile uint32_t *)0x40010800)   /* PA0~PA7  配置 */
#define GPIOA_CRH       (*(volatile uint32_t *)0x40010804)   /* PA8~PA15 配置 */
#define GPIOA_ODR       (*(volatile uint32_t *)0x4001080C)   /* 输出数据 */

#define GPIOB_CRL       (*(volatile uint32_t *)0x40010C00)
#define GPIOB_ODR       (*(volatile uint32_t *)0x40010C0C)

#define GPIOC_CRH       (*(volatile uint32_t *)0x40011004)
#define GPIOC_ODR       (*(volatile uint32_t *)0x4001100C)

/* SysTick 寄存器 */
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

/*==============================================================================
 * 毫秒延时（SysTick 轮询，不依赖中断）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U)
        {
            ;
        }
        SYSTICK_CTRL = 0x00000000U;
    }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        ;
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    /*---- 1) 开 GPIOA/B/C 和 AFIO 的时钟 ----*/
    RCC_APB2ENR |= (1U << 2) | (1U << 3) | (1U << 4);

    /*---- 2) 把 PA9、PA10 配成通用推挽输出（不是复用！）----
     * 4 位一个引脚：CNF=00（通用推挽输出） MODE=11（50MHz）→ 0011 = 0x3
     * PA9  → CRH 的 bit7~4
     * PA10 → CRH 的 bit11~8
     */
    GPIOA_CRH &= ~(0xFFU << 4);          /* 清 PA9、PA10 的配置位 */
    GPIOA_CRH |=  (0x33U << 4);          /* PA9、PA10 都配成通用推挽输出 */

    /* 顺带把 PA4、PB5、PC14 也配成推挽输出（原来接 LED 的脚）*/
    GPIOA_CRL &= ~(0xFU << 16);  GPIOA_CRL |= (0x3U << 16);   /* PA4  */
    GPIOB_CRL &= ~(0xFU << 20);  GPIOB_CRL |= (0x3U << 20);   /* PB5  */
    GPIOC_CRH &= ~(0xFU << 24);  GPIOC_CRH |= (0x3U << 24);   /* PC14 */

    /*---- 3) 主循环：每 500ms 翻转一次 ----*/
    while (1)
    {
        /* PA9、PA10 拉高 */
        GPIOA_ODR |=  (1U << 9);
        GPIOA_ODR |=  (1U << 10);
        /* PA4、PB5、PC14 拉高 */
        GPIOA_ODR |=  (1U << 4);
        GPIOB_ODR |=  (1U << 5);
        GPIOC_ODR |=  (1U << 14);

        Delay_ms(500);

        /* PA9、PA10 拉低 */
        GPIOA_ODR &= ~(1U << 9);
        GPIOA_ODR &= ~(1U << 10);
        /* PA4、PB5、PC14 拉低 */
        GPIOA_ODR &= ~(1U << 4);
        GPIOB_ODR &= ~(1U << 5);
        GPIOC_ODR &= ~(1U << 14);

        Delay_ms(500);
    }
}
