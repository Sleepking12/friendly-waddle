/*******************************************************************************
 * 文件名：main_串口自检版.c
 * 用途  ：只用电脑上的串口助手就能判断故障在哪一环
 * 芯片  ：STM32F103C8T6
 *
 * 【原理】每秒钟发送一行**内容会变化**的数据：
 *           COUNT 001
 *           COUNT 002
 *           COUNT 003
 *           ...
 *         数字一直在涨 → 证明数据是"活的"，程序真的在跑。
 *         如果收到的数字一直不变，或者完全没有，那就是有问题。
 *
 * 【怎么用】
 *   1) 打开串口助手（COM3、115200、8、1、无），点「打开串口」
 *   2) 看接收区：
 *        ┌──────────────────────┬────────────────────────────┐
 *        │ 现象                 │ 结论                       │
 *        ├──────────────────────┼────────────────────────────┤
 *        │ COUNT 数字一直在涨   │ ✅ 串口完全正常            │
 *        │ 一个字节都没有       │ 接线/CH340/COM 口问题      │
 *        │ 有乱码               │ 波特率或时钟问题           │
 *        │ 数字一直不变         │ 程序卡住了                 │
 *        └──────────────────────┴────────────────────────────┘
 *   3) 在发送框输入几个字符点发送：
 *        STM32 会原样回显 → 验证接收通道
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include <string.h>

void Error_Handler(void);

#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时（SysTick 轮询，不依赖中断）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U)
        {
            ;
        }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * 系统时钟：内部 HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * USART1 底层初始化
 *============================================================================*/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* PA10 = USART1_RX */
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}

static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 把一个数转成 3 位十进制字符串
 *============================================================================*/
static void Num3(char *buf, uint32_t n)
{
    buf[0] = (char)('0' + (n / 100U) % 10U);
    buf[1] = (char)('0' + (n / 10U) % 10U);
    buf[2] = (char)('0' + (n % 10U));
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    uint8_t  rx = 0;
    uint32_t count = 0;
    char     line[32];

    HAL_Init();
    SystemClock_Config();
    MX_USART1_UART_Init();

    /* 开机先发 3 遍固定内容（方便确认接线）*/
    for (uint32_t k = 0; k < 3U; k++)
    {
        HAL_UART_Transmit(&huart1, (uint8_t *)"BOOT OK\r\n", 9, UART_TIMEOUT);
        Delay_ms(200);
    }

    while (1)
    {
        /*---- 拼一行 "COUNT 001\r\n" ----*/
        memcpy(line, "COUNT ", 6);
        Num3(&line[6], count);
        line[9]  = '\r';
        line[10] = '\n';

        /*---- 发送 ----*/
        HAL_UART_Transmit(&huart1, (uint8_t *)line, 11, UART_TIMEOUT);

        count++;
        if (count > 999U)
        {
            count = 0U;
        }

        /*---- 收字符就回显 ----*/
        if (HAL_UART_Receive(&huart1, &rx, 1, 500U) == HAL_OK)
        {
            HAL_UART_Transmit(&huart1, (uint8_t *)"[收到] ", 8, UART_TIMEOUT);
            HAL_UART_Transmit(&huart1, &rx, 1, UART_TIMEOUT);
            HAL_UART_Transmit(&huart1, (uint8_t *)"\r\n", 2, UART_TIMEOUT);
        }
    }
}
