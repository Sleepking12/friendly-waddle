/*******************************************************************************
 * 文件名：main_纯发送测试.c
 * 用途  ：只发不收，验证串口发送通道（排除接收逻辑的干扰）
 * 芯片  ：STM32F103C8T6
 *
 * 【现象】每秒发送一行 "Txxxx OK"，x 是不断增长的计数
 *          T0001 OK
 *          T0002 OK
 *          T0003 OK
 *          ...
 *
 * 【为什么"只发不收"】
 *   上一版有 HAL_UART_Receive() 收数据的逻辑，可能是它卡住了。
 *   这版**完全不碰接收**，把变量降到最少。
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include <string.h>

void Error_Handler(void);

#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}

/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * USART1 底层初始化（只配 TX，不配 RX）
 *============================================================================*/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /* PA9 = USART1_TX */
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    }
}

static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX;          /* ★ 只开发送！*/
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    uint32_t n = 1;
    char     line[16];

    HAL_Init();
    SystemClock_Config();
    MX_USART1_UART_Init();

    /* 开机发 5 遍醒目的标记 */
    for (uint32_t k = 0; k < 5U; k++)
    {
        HAL_UART_Transmit(&huart1, (uint8_t *)"<<START>>\r\n", 11, UART_TIMEOUT);
        Delay_ms(100);
    }

    while (1)
    {
        /* 拼 "Txxxx OK\r\n" */
        line[0] = 'T';
        line[1] = (char)('0' + (n / 1000U) % 10U);
        line[2] = (char)('0' + (n / 100U) % 10U);
        line[3] = (char)('0' + (n / 10U) % 10U);
        line[4] = (char)('0' + (n % 10U));
        line[5] = ' ';
        line[6] = 'O';
        line[7] = 'K';
        line[8] = '\r';
        line[9] = '\n';

        HAL_UART_Transmit(&huart1, (uint8_t *)line, 10, UART_TIMEOUT);

        n++;
        if (n > 9999U) { n = 1U; }

        Delay_ms(1000);
    }
}
