/*******************************************************************************
 * 文件名：main_HAL自检.c
 * 用途  ：逐步定位卡在哪一步（用板载 PC13 灯的闪烁模式表示进度）
 * 芯片  ：STM32F103C8T6
 *
 * 【灯的闪烁模式 = 程序跑到哪一步】
 *
 *   模式 A：灯常亮不灭            → 卡在 HAL_Init()
 *   模式 B：闪 1 次后常亮         → 卡在 SystemClock_Config()
 *   模式 C：闪 2 次后常亮         → 卡在 USART1_Init()
 *   模式 D：一直慢闪（每 0.5 秒）  → 全部通过，程序正常运行
 *
 * 【怎么看】
 *   下载/上电后，数一下灯闪了几次：
 *     0 次就常亮 → HAL_Init 卡住
 *     1 次       → SystemClock_Config 卡住
 *     2 次       → USART1_Init 卡住
 *     一直闪     → 全部正常
 ******************************************************************************/

#include "stm32f1xx_hal.h"

void Error_Handler(void);

/* 寄存器直接操作 */
#define RCC_APB2ENR     (*(volatile uint32_t *)0x40021018)
#define GPIOC_CRH       (*(volatile uint32_t *)0x40011004)
#define GPIOC_ODR       (*(volatile uint32_t *)0x4001100C)

/* SysTick */
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

static UART_HandleTypeDef huart1;

/*==============================================================================
 * 毫秒延时（SysTick 轮询）
 *============================================================================*/
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}

static void PC13_Init(void)
{
    RCC_APB2ENR |= (1U << 4);
    GPIOC_CRH &= ~(0xFU << 20);
    GPIOC_CRH |=  (0x2U << 20);
    GPIOC_ODR |=  (1U << 13);       /* 先熄灭 */
}

static void Blink(uint32_t times)
{
    uint32_t i;
    for (i = 0; i < times; i++)
    {
        GPIOC_ODR &= ~(1U << 13);   /* 亮 */
        Delay_ms(250);
        GPIOC_ODR |=  (1U << 13);   /* 灭 */
        Delay_ms(250);
    }
}

/*==============================================================================
 * 被测试的三个函数
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

static void USART1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin   = GPIO_PIN_9;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200U;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

/*==============================================================================
 * 主函数：用灯的闪烁次数报告进度
 *============================================================================*/
int main(void)
{
    PC13_Init();

    /*--- 第 0 步：先闪 5 次（表示程序已启动，纯寄存器，一定成功）---*/
    Blink(5);

    /*--- 第 1 步：调 HAL_Init() ---
     * 如果这里卡住，灯会一直亮着不灭
     */
    HAL_Init();
    Blink(1);       /* 闪 1 次 = HAL_Init() 通过了 */

    /*--- 第 2 步：系统时钟 ---*/
    SystemClock_Config();
    Blink(2);       /* 闪 2 次 = SystemClock_Config() 通过了 */

    /*--- 第 3 步：串口初始化 ---*/
    USART1_Init();
    Blink(3);       /* 闪 3 次 = USART1_Init() 通过了 */

    /*--- 第 4 步：全部通过，一直慢闪 ---*/
    while (1)
    {
        GPIOC_ODR &= ~(1U << 13);
        Delay_ms(500);
        GPIOC_ODR |=  (1U << 13);
        Delay_ms(500);

        /* 顺便发个串口数据 */
        HAL_UART_Transmit(&huart1, (uint8_t *)"OK\r\n", 4, 100U);
    }
}
