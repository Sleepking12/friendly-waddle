﻿//

#include "stm32f1xx_hal.h"
#include <string.h>

void Error_Handler(void);

/*==================== 串口与 DMA 参数 ====================*/
#define UART_BAUDRATE       115200U
#define UART_TIMEOUT        100U

/* SysTick 寄存器 */
#define SYSTICK_CTRL    (*(volatile uint32_t *)0xE000E010)
#define SYSTICK_LOAD    (*(volatile uint32_t *)0xE000E014)
#define SYSTICK_VAL     (*(volatile uint32_t *)0xE000E018)

/*---------------- 全局变量 ----------------*/
static UART_HandleTypeDef huart1;
static DMA_HandleTypeDef  hdma_usart1_tx;      /* ★ 必须是全局变量！*/

/* 要连续发送的数据（DMA 从这块内存搬到 USART1->DR）*/
static uint8_t g_DmaBuf[] = "STM32 USART1 DMA TEST : 0123456789ABCDEF\r\n";

/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }
    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*==============================================================================
 * 毫秒延时（SysTick 轮询）—— 本工程用不到，包起来消除警告
 *============================================================================*/
#if 0
static void Delay_ms(uint32_t ms)
{
    while (ms--)
    {
        SYSTICK_LOAD = 1000U - 1U;
        SYSTICK_VAL  = 0U;
        SYSTICK_CTRL = 0x00000005U;
        while ((SYSTICK_CTRL & (1U << 16)) == 0U) { ; }
        SYSTICK_CTRL = 0x00000000U;
    }
}
#endif

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * ★ 中断服务函数
 *============================================================================*/
void SysTick_Handler(void)    { HAL_IncTick(); }
void NMI_Handler(void)        { while (1) { ; } }
void HardFault_Handler(void)  { while (1) { ; } }
void MemManage_Handler(void)  { while (1) { ; } }
void BusFault_Handler(void)   { while (1) { ; } }
void UsageFault_Handler(void) { while (1) { ; } }
void SVC_Handler(void)        { ; }
void DebugMon_Handler(void)   { ; }
void PendSV_Handler(void)     { ; }

/*---- DMA1 通道 4 中断（USART1_TX 的 DMA 用）----*/
void DMA1_Channel4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_usart1_tx);
}

/*---- ★ USART1 中断服务函数（DMA 方式也必须要有！）----
 *
 * 为什么 DMA 方式还需要 USART1 中断？
 *   DMA 只是在内存和 USART1->DR 之间搬数据。当全部数据搬完（DMA 传输完成）时，
 *   HAL 库的 UART_DMATransmitCplt() 会打开 USART1 的"发送完成(TC)"中断，
 *   等最后一个字节真正从移位寄存器发完之后，才把 gState 恢复成 READY。
 *
 *   如果没有这个中断服务函数：
 *     ① 中断没有处理函数 → 跳到 Default_Handler 的 B . 死循环 → 程序卡死
 *     ② gState 永远停在 BUSY_TX → 后续 HAL_UART_Transmit_DMA() 全返回 HAL_BUSY
 *   现象就是：按一次复位只能发一次数据。
 */
void USART1_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart1);
}

/*==============================================================================
 * USART1 底层初始化（GPIO + 时钟 + **DMA**）
 *============================================================================*/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if (huart->Instance == USART1)
    {
        /*---- 1) 开时钟 ----*/
        __HAL_RCC_USART1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();

        /*---- 2) PA9 = USART1_TX：复用推挽输出 ----*/
        GPIO_InitStruct.Pin   = GPIO_PIN_9;
        GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /*---- 3) PA10 = USART1_RX：上拉输入 ----*/
        GPIO_InitStruct.Pin  = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /*---- 4) ★ 配置 DMA1_Channel4 给 USART1_TX 用 ----*/
        __HAL_RCC_DMA1_CLK_ENABLE();

        hdma_usart1_tx.Instance                 = DMA1_Channel4;
        hdma_usart1_tx.Init.Direction           = DMA_MEMORY_TO_PERIPH;  /* 内存→外设 */
        hdma_usart1_tx.Init.PeriphInc           = DMA_PINC_DISABLE;      /* 外设地址不自增 */
        hdma_usart1_tx.Init.MemInc              = DMA_MINC_ENABLE;       /* 内存地址自增 */
        hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;   /* 按字节传输 */
        hdma_usart1_tx.Init.MemDataAlignment    = DMA_MDATAALIGN_BYTE;
        hdma_usart1_tx.Init.Mode                = DMA_NORMAL;            /* 普通模式（发完即停）*/
        hdma_usart1_tx.Init.Priority            = DMA_PRIORITY_HIGH;     /* 高优先级 */

        if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
        {
            Error_Handler();
        }

        /* ★ 把 DMA 句柄挂到 UART 句柄上，HAL_UART_Transmit_DMA 才能用 */
        __HAL_LINKDMA(huart, hdmatx, hdma_usart1_tx);

        /*---- 5) 使能 DMA1 通道 4 中断（DMA 搬完数据时进）----*/
        HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 2, 0);
        HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);

        /*---- 6) ★ 使能 USART1 中断 ----
         * 为什么需要？DMA 搬完数据后，HAL 库的 UART_DMATransmitCplt() 里会执行：
         *     __HAL_UART_ENABLE_IT(huart, UART_IT_TC);   ← 打开"发送完成"中断
         * 用来等最后一个字节真正从移位寄存器发出去，然后才能把 gState 置回 READY。
         * 如果没使能这个中断，gState 永远停在 BUSY_TX：
         *     → 下一次 HAL_UART_Transmit_DMA() 返回 HAL_BUSY
         *     → 再也发不出数据（现象：按一次复位只能发一次）
         * 而且中断没处理函数会跳到 Default_Handler 死循环。
         */
        HAL_NVIC_SetPriority(USART1_IRQn, 1, 0);
        HAL_NVIC_EnableIRQ(USART1_IRQn);
    }
}

/*==============================================================================
 * 初始化 USART1
 *============================================================================*/
static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = UART_BAUDRATE;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;

    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

static void UART_SendString(const char *str)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)str, (uint16_t)strlen(str), UART_TIMEOUT);
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_USART1_UART_Init();

    UART_SendString("\r\n===== TASK 2-3 : USART1 DMA transmit =====\r\n");
    UART_SendString("USART1  115200bps  8 data bits  1 stop bit  no parity\r\n\r\n");

    while (1)
    {
        /*---- ★ 用 DMA 发送：把 g_DmaBuf 里的数据自动搬到 USART1->DR ----
         * sizeof(g_DmaBuf) - 1 是去掉字符串结尾的 '\0'
         */
        if (HAL_UART_Transmit_DMA(&huart1, g_DmaBuf, sizeof(g_DmaBuf) - 1U) == HAL_OK)
        {
            /* 等这次 DMA 发送完成（实际工程里可用发送完成中断代替轮询）*/
            while (huart1.gState != HAL_UART_STATE_READY)
            {
                ;
            }
        }
    }
}
