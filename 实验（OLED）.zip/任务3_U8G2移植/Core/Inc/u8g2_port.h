﻿#ifndef __U8G2_PORT_H
#define __U8G2_PORT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "u8g2.h"

/*==================== 硬件连接（和 oled.h 保持一致）====================
 *
 *   OLED        STM32
 *    VCC   ────  3.3V
 *    GND   ────  GND
 *    SCL   ────  PB6
 *    SDA   ────  PB7
 *============================================================*/
#define U8G2_SCL_PORT       GPIOB
#define U8G2_SCL_PIN        GPIO_PIN_6
#define U8G2_SDA_PORT       GPIOB
#define U8G2_SDA_PIN        GPIO_PIN_7

/*==================== u8g2 句柄（在 u8g2_port.c 中定义）====================*/
extern u8g2_t u8g2;

/*==================== 对外接口 ====================*/
void U8G2_Init(void);                               /* 初始化 U8G2 与屏幕 */

/* 用自建汉字字库显示一个汉字（通过 u8g2_DrawBitmap）*/
void U8G2_DrawChinese(int x, int y, const char *ch);
void U8G2_DrawCNString(int x, int y, const char *str);

/* 绘制"列优先"格式的位图（我们的字库/头像都是这种格式）
 *   w：宽度（像素）  h：高度（像素，必须是 8 的倍数）
 *   bmp：数据，每字节 = 一列的 8 个垂直像素，bit0 在上
 */
void U8G2_DrawBitmapCM(int x, int y, int w, int h, const unsigned char *bmp);

#ifdef __cplusplus
}
#endif

#endif /* __U8G2_PORT_H */
