﻿/*******************************************************************************
 * 文件名：main.c  （U8G2 版本 —— 对应任务 3）
 * 实验3-OLED显示 · 任务3：U8G2 移植 + 4 项显示功能
 * 芯片  ：STM32F103C8T6        库：U8G2 + STM32 HAL
 *
 * ============================ 一、任务3 的 4 项要求 ============================
 *   1) U8G2 的 demo 例程
 *   2) 显示学号和名字
 *   3) 掌握上下、左右滑动显示方法
 *   4) 显示一个图案（头像），最好有动态效果
 *
 *   用 DEMO_MODE 选择：
 *       DEMO_MODE = 1   ① U8G2 图形 demo
 *       DEMO_MODE = 2   ② 学号姓名
 *       DEMO_MODE = 3   ③ 左右滑动 + 上下滑动
 *       DEMO_MODE = 4   ④ 头像 + 眨眼动画
 *
 * ============================ 二、U8G2 移植要点 ============================
 *   详见 u8g2_port.c 和《U8G2移植指南.md》，核心是三个函数：
 *       u8x8_byte_sw_i2c()        把字节通过软件 I2C 发出去
 *       u8x8_gpio_delay_stm32()   延时
 *       U8G2_Init()               选择驱动并绑定回调
 *
 *   汉字处理：U8G2 自带汉字库太大（70~200KB，C8T6 装不下），
 *   所以用自建 16x16 字库 + u8g2_DrawBitmap() 画汉字。
 *
 * ============================ 三、硬件 ============================
 *   OLED VCC ── 3.3V      OLED GND ── GND
 *   OLED SCL ── PB6       OLED SDA ── PB7
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include "u8g2_port.h"
#include "oledfont.h"
#include <string.h>

void Error_Handler(void);

/*==================== 选择演示 ====================*/
#define DEMO_MODE           1

/*==================== 个人信息 ====================*/
#define MY_ID               "632407030110"
#define MY_NAME             "吴思伟"

/*==================== 头像 32x32 位图（u8g2_DrawBitmap 格式）====================*/
/* 格式：列优先，每 8 行 1 字节，bit0 在上；32 宽 = 4 个字节列 */
static const unsigned char Avatar_Open[] = {
    0x00, 0x00, 0x00, 0x00, 0x80, 0xC0, 0xE0, 0xF0,
    0xF8, 0xF8, 0xFC, 0xFC, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFC, 0xFC, 0xF8, 0xF8,
    0xF0, 0xE0, 0xC0, 0x80, 0x00, 0x00, 0x00, 0x00,
    0x00, 0xF0, 0xFC, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0x0F, 0x07, 0x07, 0x07, 0x0F, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0x0F, 0x07, 0x07, 0x07, 0x0F,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0xF0, 0x00,
    0x00, 0x0F, 0x3F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFE, 0xFE, 0xFE, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFE, 0xFE, 0xFE, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x3F, 0x0F, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x01, 0x03, 0x07, 0x0F,
    0x1E, 0x1C, 0x38, 0x31, 0x73, 0x63, 0x67, 0x67,
    0x67, 0x67, 0x67, 0x63, 0x33, 0x31, 0x18, 0x1C,
    0x0F, 0x07, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00,
};

static const unsigned char Avatar_Blink[] = {
    0x00, 0x00, 0x00, 0x00, 0x80, 0xC0, 0xE0, 0xF0,
    0xF8, 0xF8, 0xFC, 0xFC, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFC, 0xFC, 0xF8, 0xF8,
    0xF0, 0xE0, 0xC0, 0x80, 0x00, 0x00, 0x00, 0x00,
    0x00, 0xF0, 0xFC, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0x9F, 0x9F, 0x9F, 0x9F, 0x9F, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0x9F, 0x9F, 0x9F, 0x9F, 0x9F,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0xF0, 0x00,
    0x00, 0x0F, 0x3F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x3F, 0x0F, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x01, 0x03, 0x07, 0x0F,
    0x1E, 0x1C, 0x38, 0x31, 0x73, 0x63, 0x67, 0x67,
    0x67, 0x67, 0x67, 0x63, 0x33, 0x31, 0x18, 0x1C,
    0x0F, 0x07, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00,
};


/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * ★ 中断服务函数（HAL 库必需）
 *============================================================================*/
void SysTick_Handler(void)    { HAL_IncTick(); }
void NMI_Handler(void)        { while (1) { ; } }
void HardFault_Handler(void)  { while (1) { ; } }
void MemManage_Handler(void)  { while (1) { ; } }
void BusFault_Handler(void)   { while (1) { ; } }
void UsageFault_Handler(void) { while (1) { ; } }
void SVC_Handler(void)        { ; }
void DebugMon_Handler(void)   { ; }
void PendSV_Handler(void)     { ; }

/*==============================================================================
 * 演示 ①：U8G2 图形 demo 例程
 *   —— 画线、矩形、圆、三角形、多种字体
 *============================================================================*/
#if (DEMO_MODE == 1)
static void Demo_Graphics(void)
{
    uint8_t frame = 0;

    while (1)
    {
        u8g2_ClearBuffer(&u8g2);

        /*---- 标题 ----*/
        u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
        u8g2_DrawStr(&u8g2, 0, 10, "U8G2 Demo");

        /*---- 画横线 ----*/
        u8g2_DrawHLine(&u8g2, 0, 13, 128);

        /*---- 画矩形（空心）----*/
        u8g2_DrawFrame(&u8g2, 2, 16, 30, 20);

        /*---- 画实心矩形 ----*/
        u8g2_DrawBox(&u8g2, 36, 16, 30, 20);

        /*---- 画圆（空心 / 实心）----*/
        u8g2_DrawCircle(&u8g2, 82, 26, 10, U8G2_DRAW_ALL);
        u8g2_DrawDisc(&u8g2, 110, 26, 10, U8G2_DRAW_ALL);

        /*---- 画三角形 ----*/
        {
            u8g2_uint_t x0 = 10, y0 = 58;
            u8g2_uint_t x1 = 30, y1 = 40;
            u8g2_uint_t x2 = 50, y2 = 58;
            u8g2_DrawTriangle(&u8g2, x0, y0, x1, y1, x2, y2);
        }

        /*---- 画多条斜线（动态效果：随时间移动）----*/
        {
            uint8_t i;
            for (i = 0; i < 6; i++)
            {
                u8g2_DrawLine(&u8g2,
                              (u8g2_uint_t)(60 + i * 10),
                              (u8g2_uint_t)(40 + (frame + i * 3) % 20),
                              (u8g2_uint_t)(128),
                              (u8g2_uint_t)(40 + (frame + i * 5) % 20));
            }
        }

        /*---- 用不同字体写数字 ----*/
        u8g2_SetFont(&u8g2, u8g2_font_8x13B_tf);
        u8g2_DrawStr(&u8g2, 60, 60, "2024");

        u8g2_SendBuffer(&u8g2);

        frame++;
        HAL_Delay(150);
    }
}
#endif

/*==============================================================================
 * 演示 ②：显示学号和姓名
 *   学号 12 位数字 → 用 U8G2 的 6x10 字体（8 像素宽）
 *   姓名用自建汉字字库
 *============================================================================*/
#if (DEMO_MODE == 2)
static void Demo_ID(void)
{
    u8g2_ClearBuffer(&u8g2);

    /*---- 第 1 行：学号 ----*/
    U8G2_DrawCNString(0, 0, "学号");                /* 汉字 32 像素宽 */
    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    u8g2_DrawStr(&u8g2, 34, 12, MY_ID);             /* 12 位数字 */

    /*---- 分隔线 ----*/
    u8g2_DrawHLine(&u8g2, 0, 17, 128);

    /*---- 第 2 行：姓名 ----*/
    U8G2_DrawCNString(0, 20, "姓名");
    u8g2_DrawStr(&u8g2, 34, 32, ":");
    U8G2_DrawCNString(42, 20, MY_NAME);

    /*---- 分隔线 ----*/
    u8g2_DrawHLine(&u8g2, 0, 38, 128);

    /*---- 第 3~4 行：说明 ----*/
    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    u8g2_DrawStr(&u8g2, 0, 50, "STM32F103 + U8G2");
    u8g2_DrawStr(&u8g2, 0, 62, "SSD1306  I2C");

    u8g2_SendBuffer(&u8g2);

    while (1)
    {
        HAL_Delay(1000);
    }
}
#endif

/*==============================================================================
 * 演示 ③：滑动显示（左右 + 上下）
 *   左右滑动：改变 x 坐标，让长字符串从右往左跑
 *   上下滑动：改变 y 坐标，让整行文字上下移动
 *============================================================================*/
#if (DEMO_MODE == 3)
static void Demo_Scroll(void)
{
    const char *text = "Hello, welcome to Chongqing Jiaotong University!";
    int textW;
    int offset;
    int y;
    uint8_t phase = 0;

    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    textW = (int)u8g2_GetStrWidth(&u8g2, text);

    while (1)
    {
        /*---- ① 左右滑动：从右往左 ----*/
        for (offset = 0; offset <= textW; offset += 4)
        {
            u8g2_ClearBuffer(&u8g2);

            u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
            U8G2_DrawCNString(0, 0, "重庆交通大学");
            u8g2_DrawHLine(&u8g2, 0, 17, 128);

            /* 关键：x 传负值，u8g2 会自动裁剪屏幕外的部分 */
            u8g2_DrawStr(&u8g2, (u8g2_uint_t)(128 - offset), 40, text);

            u8g2_DrawHLine(&u8g2, 0, 50, 128);
            U8G2_DrawCNString(0, 52, "欢迎来到");

            u8g2_SendBuffer(&u8g2);
            HAL_Delay(30);
        }

        /*---- ② 上下滑动：整行文字上下移动 ----*/
        for (phase = 0; phase < 2; phase++)
        {
            for (y = 0; y <= 50; y += 2)
            {
                u8g2_ClearBuffer(&u8g2);

                if (phase == 0)
                {
                    U8G2_DrawCNString(0, y, "物联网实训室");
                }
                else
                {
                    U8G2_DrawCNString(0, 50 - y, "物联网实训室");
                }

                u8g2_SendBuffer(&u8g2);
                HAL_Delay(30);
            }
        }

        HAL_Delay(500);
    }
}
#endif

/*==============================================================================
 * 演示 ④：头像图案 + 动态效果（眨眼）
 *============================================================================*/
#if (DEMO_MODE == 4)
static void Demo_Avatar(void)
{
    uint16_t t = 0;

    while (1)
    {
        u8g2_ClearBuffer(&u8g2);

        /*---- 画头像（32x32）----
         * 每 60 帧（约 3 秒）眨一次眼，闭眼只保持 2 帧
         */
        if ((t % 60) >= 56 && (t % 60) < 58)
        {
            u8g2_DrawBitmap(&u8g2, 8, 16, 4, 32, Avatar_Blink);   /* 闭眼 */
        }
        else
        {
            u8g2_DrawBitmap(&u8g2, 8, 16, 4, 32, Avatar_Open);    /* 睁眼 */
        }

        /*---- 右边的文字 ----*/
        u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
        U8G2_DrawCNString(48, 12, "姓名");
        U8G2_DrawCNString(48, 32, MY_NAME);

        u8g2_DrawStr(&u8g2, 48, 58, MY_ID);

        /*---- 底部滚动的小方块（动态效果）----*/
        u8g2_DrawBox(&u8g2, (u8g2_uint_t)((t * 3) % 120), 62, 8, 2);

        u8g2_SendBuffer(&u8g2);

        t++;
        HAL_Delay(50);
    }
}
#endif

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    HAL_Init();                 /* HAL 初始化（打开 SysTick 中断）*/
    SystemClock_Config();       /* 系统时钟 8MHz */
    U8G2_Init();                /* U8G2 + OLED 初始化 */

    /*---- 开机画面 ----*/
    u8g2_ClearBuffer(&u8g2);
    u8g2_SetFont(&u8g2, u8g2_font_6x10_tf);
    u8g2_DrawStr(&u8g2, 24, 20, "U8G2  Port OK");
    U8G2_DrawCNString(16, 32, "重庆交通大学");
    u8g2_DrawStr(&u8g2, 20, 60, "STM32F103C8T6");
    u8g2_SendBuffer(&u8g2);
    HAL_Delay(1500);

#if (DEMO_MODE == 1)
    Demo_Graphics();
#elif (DEMO_MODE == 2)
    Demo_ID();
#elif (DEMO_MODE == 3)
    Demo_Scroll();
#else
    Demo_Avatar();
#endif

    while (1)
    {
        ;
    }
}
