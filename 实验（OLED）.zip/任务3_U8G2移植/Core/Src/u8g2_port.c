﻿/*******************************************************************************
 * 文件名：u8g2_port.c
 * 功能  ：U8G2 在 STM32F103（HAL 库）上的移植层
 *
 * ============================ 移植原理 ============================
 *   U8G2 把"平台相关"的部分抽象成两个回调函数：
 *
 *     ① u8x8_byte_stm32_sw_i2c()       —— 负责把字节按 I2C 发出去
 *     ② u8x8_gpio_delay_stm32()  —— 负责延时和复位引脚
 *
 *   只要实现这两个函数，U8G2 就能在任何平台上跑起来。
 *
 * ============================ 为什么用软件 I2C ============================
 *   硬件 I2C 的引脚是"复用开漏"(AF_OD)，由 I2C 外设驱动，
 *   GPIO 的 ODR 寄存器不再变化 → Keil 逻辑分析仪读 ODR → 看不到波形。
 *   用 GPIO 模拟 I2C，引脚是普通 GPIO，ODR 会跟着翻转 →
 *   逻辑分析仪能看到完整的起始/地址/数据/应答/停止时序。
 *
 * ============================ 编译前提 ============================
 *   需要先把 U8G2 的源码（u8g2.h、u8x8.h 和裁剪后的 .c 文件）
 *   加入工程，详见《U8G2移植指南.md》
 ******************************************************************************/

#include "u8g2_port.h"
#include "oledfont.h"           /* 复用自建汉字字库 */
#include "stm32f1xx_hal.h"

/*==================== 全局 u8g2 句柄 ====================*/
u8g2_t u8g2;

/*==================== 引脚操作宏 ====================*/
#define SCL_H()     HAL_GPIO_WritePin(U8G2_SCL_PORT, U8G2_SCL_PIN, GPIO_PIN_SET)
#define SCL_L()     HAL_GPIO_WritePin(U8G2_SCL_PORT, U8G2_SCL_PIN, GPIO_PIN_RESET)
#define SDA_H()     HAL_GPIO_WritePin(U8G2_SDA_PORT, U8G2_SDA_PIN, GPIO_PIN_SET)
#define SDA_L()     HAL_GPIO_WritePin(U8G2_SDA_PORT, U8G2_SDA_PIN, GPIO_PIN_RESET)
#define SDA_READ()  HAL_GPIO_ReadPin(U8G2_SDA_PORT, U8G2_SDA_PIN)

/*==============================================================================
 * 软件 I2C 底层
 *============================================================================*/
static void IIC_Delay(void)
{
    volatile uint32_t i = 12;
    while (i--) { __NOP(); }
}

static void IIC_Start(void)
{
    SDA_H();
    SCL_H();
    IIC_Delay();
    SDA_L();            /* SCL 高时 SDA 下降沿 = 起始 */
    IIC_Delay();
    SCL_L();
    IIC_Delay();
}

static void IIC_Stop(void)
{
    SDA_L();
    SCL_H();
    IIC_Delay();
    SDA_H();            /* SCL 高时 SDA 上升沿 = 停止 */
    IIC_Delay();
}

static uint8_t IIC_WaitAck(void)
{
    uint8_t ret;

    SDA_H();            /* 释放 SDA，由从机拉低 */
    IIC_Delay();
    SCL_H();
    IIC_Delay();

    ret = (SDA_READ() == GPIO_PIN_SET) ? 1 : 0;

    SCL_L();
    IIC_Delay();
    return ret;
}

static void IIC_SendByte(uint8_t dat)
{
    uint8_t i;

    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80) { SDA_H(); }
        else            { SDA_L(); }

        dat <<= 1;
        IIC_Delay();
        SCL_H();
        IIC_Delay();
        SCL_L();
        IIC_Delay();
    }

    IIC_WaitAck();
}

/*==============================================================================
 * ★ 回调函数 ①：字节发送（U8G2 → I2C 总线）
 *
 * 注意：函数名不能叫 u8x8_byte_sw_i2c —— 那是 U8G2 库内部自带的
 *       软件 I2C 实现，重名会报 "multiply defined"。
 *       所以这里命名为 u8x8_byte_stm32_sw_i2c。
 *
 * U8G2 会用下面几个消息调用本函数：
 *   U8X8_MSG_BYTE_INIT             初始化引脚
 *   U8X8_MSG_BYTE_START_TRANSFER   起始信号 + 从机地址
 *   U8X8_MSG_BYTE_SEND             发送 arg_int 个字节
 *   U8X8_MSG_BYTE_END_TRANSFER     停止信号
 *============================================================================*/
uint8_t u8x8_byte_stm32_sw_i2c(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
    uint8_t *data;
    uint8_t i;

    switch (msg)
    {
        case U8X8_MSG_BYTE_INIT:
            /* 引脚已在 U8G2_Init() 里配置好，这里不用做 */
            break;

        case U8X8_MSG_BYTE_START_TRANSFER:
            IIC_Start();
            /* ★ 软件 I2C 要自己发送从机地址
             * u8x8_GetI2CAddress() 返回的是已经左移 1 位的 8 位地址（0x78）
             */
            IIC_SendByte(u8x8_GetI2CAddress(u8x8));
            break;

        case U8X8_MSG_BYTE_SEND:
            data = (uint8_t *)arg_ptr;
            for (i = 0; i < arg_int; i++)
            {
                IIC_SendByte(data[i]);
            }
            break;

        case U8X8_MSG_BYTE_END_TRANSFER:
            IIC_Stop();
            break;

        default:
            return 0;
    }

    return 1;
}

/*==============================================================================
 * ★ 回调函数 ②：GPIO 与延时
 *
 * U8G2 会用下面几个消息调用本函数：
 *   U8X8_MSG_GPIO_AND_DELAY_INIT   初始化（可以什么都不做）
 *   U8X8_MSG_DELAY_MILLI           延时 arg_int 毫秒
 *   U8X8_MSG_DELAY_10MICRO         延时 10 微秒
 *   U8X8_MSG_DELAY_100NANO         延时 100 纳秒（忽略）
 *   U8X8_MSG_GPIO_RESET            拉复位脚（本模块没有，忽略）
 *============================================================================*/
uint8_t u8x8_gpio_delay_stm32(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr)
{
    (void)u8x8;
    (void)arg_ptr;

    switch (msg)
    {
        case U8X8_MSG_GPIO_AND_DELAY_INIT:
            /* 延时用 HAL_Delay，SysTick 已在 HAL_Init() 里配好 */
            break;

        case U8X8_MSG_DELAY_MILLI:
            HAL_Delay(arg_int);
            break;

        case U8X8_MSG_DELAY_10MICRO:
            {
                volatile uint32_t i = arg_int * 40U;   /* 8MHz 下约 10us/次 */
                while (i--) { __NOP(); }
            }
            break;

        case U8X8_MSG_DELAY_100NANO:
            __NOP();
            break;

        case U8X8_MSG_GPIO_RESET:
            /* OLED 模块没有复位脚，忽略 */
            break;

        default:
            return 0;
    }

    return 1;
}

/*==============================================================================
 * 函数名：U8G2_Init
 * 功能  ：初始化 U8G2 和 OLED
 * 说明  ：_f 后缀 = 全缓冲模式（128x64 位 = 1024 字节 RAM）
 *============================================================================*/
void U8G2_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /*---- 1) 配置 SCL / SDA 为开漏输出 + 上拉 ----*/
    __HAL_RCC_GPIOB_CLK_ENABLE();

    SCL_H();
    SDA_H();

    GPIO_InitStruct.Pin   = U8G2_SCL_PIN | U8G2_SDA_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;    /* 开漏（I2C 要求）*/
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    HAL_Delay(100);         /* 等 OLED 上电稳定 */

    /*---- 2) 选择驱动并绑定回调 ----
     * ssd1306       : 控制器型号
     * i2c           : 接口类型
     * 128x64        : 分辨率
     * noname        : 无厂商后缀（通用模块）
     * _f            : 全缓冲模式
     * U8G2_R0       : 不旋转
     */
    u8g2_Setup_ssd1306_i2c_128x64_noname_f(
            &u8g2,
            U8G2_R0,
            u8x8_byte_stm32_sw_i2c,
            u8x8_gpio_delay_stm32);

    /*---- 3) 初始化屏幕 ----*/
    u8g2_InitDisplay(&u8g2);
    u8g2_SetPowerSave(&u8g2, 0);        /* 0 = 点亮 */

    /*---- 4) 清屏 ----*/
    u8g2_ClearBuffer(&u8g2);
    u8g2_SendBuffer(&u8g2);
}

/*==============================================================================
 * 函数名：U8G2_DrawChinese
 * 功能  ：用自建 16x16 字库画一个汉字
 * 参数  ：x, y —— 左上角坐标；ch —— UTF-8 汉字（3 字节）
 *
 * 说明  ：u8g2_DrawBitmap 的位图格式是"列优先，每 8 行 1 字节，bit0 在上"，
 *         和我们字库的格式完全一致，所以可以直接把字模数组传进去。
 *============================================================================*/
void U8G2_DrawChinese(int x, int y, const char *ch)
{
    int idx, page, col, bit;
    uint8_t b;

    if (ch == 0) { return; }

    idx = OLED_FindChinese(ch);
    if (idx < 0) { return; }

    /*==================================================================
     * 为什么不用 u8g2_DrawBitmap()？
     *
     *   u8g2_DrawBitmap() 要的数位图格式（XBM）是**行优先**的：
     *       一个字节 = 一行里连续 8 个**水平**像素
     *       排列顺序：先按行块（8 行一组），再按列
     *
     *   而我们自建字库是**列优先**的（SSD1306 原生格式）：
     *       一个字节 = 一列里连续 8 个**垂直**像素
     *       排列顺序：先按页（8 行一组），再按列
     *
     *   两者是**转置关系**，直接传进去汉字会错位成一团。
     *
     *   所以这里改用最稳妥的办法：**逐点绘制**。
     *   虽然慢一点（一个汉字 256 次 DrawPixel），但保证正确。
     * ================================================================== */
    for (page = 0; page < 2; page++)            /* 16x16 占 2 页 */
    {
        for (col = 0; col < 16; col++)          /* 16 列 */
        {
            b = F16x16_CN[idx][page * 16 + col];
            if (b == 0) { continue; }           /* 空列直接跳过，省时间 */

            for (bit = 0; bit < 8; bit++)       /* 每列的 8 个像素 */
            {
                if (b & (1u << bit))
                {
                    u8g2_DrawPixel(&u8g2,
                                   (u8g2_uint_t)(x + col),
                                   (u8g2_uint_t)(y + page * 8 + bit));
                }
            }
        }
    }
}

/*==============================================================================
 * 函数名：U8G2_DrawBitmapCM
 * 功能  ：绘制"列优先"格式的位图（Column-Major）
 *
 * 说明  ：u8g2_DrawBitmap() 用的是 XBM 格式（行优先），
 *         和我们的字库、头像位图（列优先，字节 = 一列 8 个垂直像素）不兼容，
 *         直接传进去图像会转置/错乱。所以这里逐点绘制。
 *
 * 参数  ：x, y 左上角坐标
 *         w     宽度（像素）
 *         h     高度（像素），必须是 8 的倍数
 *         bmp   数据
 *============================================================================*/
void U8G2_DrawBitmapCM(int x, int y, int w, int h, const unsigned char *bmp)
{
    int page, col, bit, pages;
    unsigned char b;

    if (bmp == 0) { return; }

    pages = h / 8;

    for (page = 0; page < pages; page++)
    {
        for (col = 0; col < w; col++)
        {
            b = bmp[page * w + col];
            if (b == 0) { continue; }

            for (bit = 0; bit < 8; bit++)
            {
                if (b & (1u << bit))
                {
                    u8g2_DrawPixel(&u8g2,
                                   (u8g2_uint_t)(x + col),
                                   (u8g2_uint_t)(y + page * 8 + bit));
                }
            }
        }
    }
}

/*==============================================================================
 * 函数名：U8G2_DrawCNString
 * 功能  ：画 UTF-8 字符串（汉字 16 宽、ASCII 8 宽）
 * 说明  ：汉字用自建字库，ASCII 用 U8G2 的当前字体
 *============================================================================*/
void U8G2_DrawCNString(int x, int y, const char *str)
{
    char ascii[2];

    while (*str != 0)
    {
        if ((uint8_t)*str >= 0x80)          /* 汉字 */
        {
            U8G2_DrawChinese(x, y, str);
            x += 16;
            str += 3;
        }
        else                                /* ASCII */
        {
            ascii[0] = *str;
            ascii[1] = 0;
            u8g2_DrawStr(&u8g2, (u8g2_uint_t)x, (u8g2_uint_t)(y + 13), ascii);
            x += 8;
            str += 1;
        }
    }
}
