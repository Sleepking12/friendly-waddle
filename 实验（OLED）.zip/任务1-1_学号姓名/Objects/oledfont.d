./objects/oledfont.o: Core\Src\oledfont.c Core\Src\oledfont.h
