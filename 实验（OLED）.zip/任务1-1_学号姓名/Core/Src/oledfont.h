#ifndef __OLEDFONT_H
#define __OLEDFONT_H

#ifdef __cplusplus
extern "C" {
#endif

/*==================== 字库尺寸 ====================*/
#define OLED_ASCII_W      8        /* ASCII 字符宽 */
#define OLED_ASCII_H      16       /* ASCII 字符高 */
#define OLED_CN_W         16       /* 汉字宽 */
#define OLED_CN_H         16       /* 汉字高 */
#define OLED_CN_COUNT     37      /* 汉字个数 */

/*==================== 字库数据（存在 Flash 里）====================*/
extern const unsigned char F6x8_ASCII[][16];      /* ASCII 8x16 */
extern const unsigned char F16x16_CN[][32];       /* 汉字 16x16 */
extern const char * const OLED_CN_INDEX;          /* 汉字索引字符串 */

/*==================== 查找函数 ====================*/

/**
 * 功能：根据字符找汉字在字库中的索引
 * 参数：ch —— UTF-8 编码的一个汉字（3 字节）
 * 返回：索引 0 ~ OLED_CN_COUNT-1；找不到返回 -1
 */
int OLED_FindChinese(const char *ch);

#ifdef __cplusplus
}
#endif

#endif /* __OLEDFONT_H */
