/*******************************************************************************
 * 文件名：main.c
 * 实验3-OLED显示 —— 任务1 之 ①：显示学号和姓名
 * 芯片  ：STM32F103C8T6      工具：STM32CubeMX + Keil MDK，HAL 库
 * 屏幕  ：0.96 寸 OLED（SSD1306，128x64，I2C 接口）
 *
 * ============================ 一、功能 ============================
 *   屏幕分 4 行显示：
 *       学号632407030110
 *       姓名:吴思伟
 *       重庆交通大学
 *       物联网实训室
 *
 * ============================ 二、硬件 ============================
 *   OLED          STM32
 *    VCC    ────  3.3V
 *    GND    ────  GND
 *    SCL    ────  PB6
 *    SDA    ────  PB7
 *
 * ============================ 三、汉字点阵原理 ============================
 *   一个 16x16 汉字占 **32 字节**：
 *       2 页 × 16 列 = 32 字节
 *       每个字节代表一列的 8 个像素，bit0 在最上、bit7 在最下
 *
 *   SSD1306 的显存也是"页-列"结构（8 页 × 128 列），
 *   所以汉字字模可以直接按列写入显存，不需要逐像素转换。
 *
 *   字模由 Python 脚本用宋体渲染生成（见 oledfont.c）
 *
 * ============================ 四、版面计算 ============================
 *   屏幕宽 128 像素，汉字 16 像素宽，ASCII 8 像素宽：
 *
 *   第 1 行：学(16)号(16) + 12 位学号(12×8=96) = **128** ← 正好满屏
 *   第 2 行：姓(16)名(16) + ':'(8) + 吴思伟(3×16=48) = 88
 *   第 3 行：重庆交通大学 = 6×16 = 96
 *   第 4 行：物联网实训室 = 6×16 = 96
 *
 * ============================ 五、注意 ============================
 *   必须提供 SysTick_Handler，否则 HAL_Init() 打开 SysTick 中断后
 *   程序会卡死在 Default_Handler 的 B . 死循环里。
 ******************************************************************************/

#include "stm32f1xx_hal.h"
#include "oled.h"
#include "oledfont.h"
#include <string.h>

void Error_Handler(void);

/*==================== 个人信息 ====================*/
#define MY_ID       "632407030110"      /* 学号 */
#define MY_NAME     "吴思伟"            /* 姓名 */

/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * ★ 中断服务函数（HAL 库必需）
 *============================================================================*/
void SysTick_Handler(void)    { HAL_IncTick(); }
void NMI_Handler(void)        { while (1) { ; } }
void HardFault_Handler(void)  { while (1) { ; } }
void MemManage_Handler(void)  { while (1) { ; } }
void BusFault_Handler(void)   { while (1) { ; } }
void UsageFault_Handler(void) { while (1) { ; } }
void SVC_Handler(void)        { ; }
void DebugMon_Handler(void)   { ; }
void PendSV_Handler(void)     { ; }

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    HAL_Init();                 /* HAL 初始化（打开 SysTick 中断）*/
    SystemClock_Config();       /* 系统时钟 8MHz */
    OLED_Init();                /* OLED 初始化（含 GPIO 和软件 I2C）*/
    OLED_Clear();

    /*---- 开机画面 ----*/
    OLED_ShowCNString(16, 8, "欢迎来到");
    OLED_ShowCNString(0, 40, "重庆交通大学");
    OLED_Refresh();
    HAL_Delay(1500);

    /*---- 正式内容：学号 + 姓名 ----*/
    OLED_ClearBuffer();


    OLED_ShowCNString(0, 0, "学号");
    OLED_ShowString(32, 0, MY_ID);


    OLED_ShowCNString(0, 16, "姓名");
    OLED_ShowChar(32, 16, ':');
    OLED_ShowCNString(40, 16, MY_NAME);


    OLED_ShowCNString(0, 32, "重庆交通大学");


    OLED_ShowCNString(0, 48, "物联网实训室");

    OLED_Refresh();

    while (1)
    {
        /* 静态显示，不需要刷新 */
    }
}
