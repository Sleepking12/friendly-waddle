﻿/*******************************************************************************
 * 文件名：aht20.c
 * 功能  ：AHT20 温湿度传感器驱动（I2C）
 * 说明  ：和 OLED 共用同一条软件 I2C 总线（PB6=SCL，PB7=SDA）
 *
 * ============================ AHT20 通信流程 ============================
 *   ① 上电后先读状态字，若 bit3（校准使能位）为 0，则发送初始化命令
 *        0xBE 0x08 0x00
 *   ② 触发测量：发送 0xAC 0x33 0x00
 *   ③ 等待 80ms（测量需要时间）
 *   ④ 读 7 个字节：
 *        byte0 = 状态字（bit7 = 忙标志，1 表示还在测量）
 *        byte1~5 = 温湿度数据（20 位湿度 + 20 位温度）
 *
 * ============================ 数据换算 ============================
 *   原始 40 位数据（5 字节）：
 *      Humidity_raw = (b1<<12) | (b2<<4) | (b3>>4)      —— 20 位
 *      Temp_raw     = ((b3&0x0F)<<16) | (b4<<8) | b5    —— 20 位
 *
 *   Humidity(%) = Humidity_raw / 2^20 * 100
 *   Temp(℃)    = Temp_raw    / 2^20 * 200 - 50
 ******************************************************************************/

#include "aht20.h"
#include "oled.h"       /* 复用里面的软件 I2C 引脚宏和延时 */
#include <string.h>

/*==================== 复用 OLED 驱动里的软件 I2C ====================*/
/* 直接用 HAL 库的 GPIO 操作，引脚定义与 OLED 相同 */

static void AHT20_Delay(void)
{
    volatile uint32_t i = 12;
    while (i--) { __NOP(); }
}

static void AHT20_IIC_Start(void)
{
    OLED_SDA_H();
    OLED_SCL_H();
    AHT20_Delay();
    OLED_SDA_L();
    AHT20_Delay();
    OLED_SCL_L();
    AHT20_Delay();
}

static void AHT20_IIC_Stop(void)
{
    OLED_SDA_L();
    OLED_SCL_H();
    AHT20_Delay();
    OLED_SDA_H();
    AHT20_Delay();
}

static uint8_t AHT20_IIC_WaitAck(void)
{
    uint8_t ret;

    OLED_SDA_H();
    AHT20_Delay();
    OLED_SCL_H();
    AHT20_Delay();

    ret = (OLED_SDA_READ() == GPIO_PIN_SET) ? 1 : 0;

    OLED_SCL_L();
    AHT20_Delay();
    return ret;
}

static void AHT20_IIC_SendByte(uint8_t dat)
{
    uint8_t i;

    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80) { OLED_SDA_H(); }
        else            { OLED_SDA_L(); }

        dat <<= 1;
        AHT20_Delay();

        OLED_SCL_H();
        AHT20_Delay();
        OLED_SCL_L();
        AHT20_Delay();
    }

    AHT20_IIC_WaitAck();            /* 发送后接收应答 */
}

/*---- 读一个字节，ack = 0 表示读完后给从机应答 ----*/
static uint8_t AHT20_IIC_ReadByte(uint8_t ack)
{
    uint8_t i;
    uint8_t dat = 0;

    OLED_SDA_H();                   /* 释放 SDA，准备输入 */

    for (i = 0; i < 8; i++)
    {
        dat <<= 1;

        OLED_SCL_H();
        AHT20_Delay();

        if (OLED_SDA_READ() == GPIO_PIN_SET) { dat |= 0x01; }

        OLED_SCL_L();
        AHT20_Delay();
    }

    /* 发送应答/非应答 */
    if (ack == 0) { OLED_SDA_L(); }
    else          { OLED_SDA_H(); }

    AHT20_Delay();
    OLED_SCL_H();
    AHT20_Delay();
    OLED_SCL_L();
    OLED_SDA_H();
    AHT20_Delay();

    return dat;
}

/*---- 写寄存器 ----*/
static void AHT20_WriteReg(uint8_t *buf, uint8_t len)
{
    uint8_t i;

    AHT20_IIC_Start();
    AHT20_IIC_SendByte(AHT20_I2C_ADDR);
    for (i = 0; i < len; i++)
    {
        AHT20_IIC_SendByte(buf[i]);
    }
    AHT20_IIC_Stop();
    HAL_Delay(5);
}

/*---- 读多个字节 ----*/
static void AHT20_ReadBytes(uint8_t *buf, uint8_t len)
{
    uint8_t i;

    AHT20_IIC_Start();
    AHT20_IIC_SendByte(AHT20_I2C_ADDR | 0x01);      /* 读 */
    for (i = 0; i < len; i++)
    {
        buf[i] = AHT20_IIC_ReadByte((i == (len - 1)) ? 1 : 0);
    }
    AHT20_IIC_Stop();
}

/*==============================================================================
 * 函数名：AHT20_Init
 * 功能  ：初始化 AHT20
 * 返回  ：0 = 成功，1 = 失败（芯片没反应）
 *============================================================================*/
uint8_t AHT20_Init(void)
{
    uint8_t cmd[3];
    uint8_t status = 0;
    uint8_t retry = 0;

    HAL_Delay(100);             /* 上电后等 100ms */

    /*---- 先读状态字，看校准位 ----*/
    AHT20_ReadBytes(&status, 1);

    /*---- bit3 = 校准使能，若为 0 需要初始化 ----*/
    if ((status & 0x08) == 0)
    {
        cmd[0] = 0xBE;          /* 初始化命令 */
        cmd[1] = 0x08;
        cmd[2] = 0x00;
        AHT20_WriteReg(cmd, 3);
        HAL_Delay(10);

        /*---- 再读状态，确认校准完成 ----*/
        for (retry = 0; retry < 5; retry++)
        {
            AHT20_ReadBytes(&status, 1);
            if ((status & 0x08) != 0) { return 0; }
            HAL_Delay(20);
        }
        return 1;               /* 校准没成功 */
    }

    return 0;
}

/*==============================================================================
 * 函数名：AHT20_Read
 * 功能  ：读取温湿度
 * 参数  ：data —— 结果结构体指针
 * 返回  ：0 = 成功，1 = 失败
 *============================================================================*/
uint8_t AHT20_Read(AHT20_DataTypeDef *data)
{
    uint8_t cmd[3];
    uint8_t buf[7];
    uint32_t hum_raw, temp_raw;
    uint8_t retry;

    if (data == 0) { return 1; }

    /*---- ① 触发测量 ----*/
    cmd[0] = 0xAC;
    cmd[1] = 0x33;
    cmd[2] = 0x00;
    AHT20_WriteReg(cmd, 3);

    /*---- ② 等测量完成（约 80ms）----*/
    HAL_Delay(80);

    /*---- ③ 轮询状态字，bit7 = 忙 ----*/
    for (retry = 0; retry < 20; retry++)
    {
        AHT20_ReadBytes(buf, 1);
        if ((buf[0] & 0x80) == 0) { break; }        /* 不忙了 */
        HAL_Delay(10);
    }
    if (retry >= 20) { return 1; }

    /*---- ④ 读 7 个字节 ----*/
    AHT20_ReadBytes(buf, 7);

    /*---- ⑤ 数据换算 ----*/
    hum_raw  = ((uint32_t)buf[1] << 12) | ((uint32_t)buf[2] << 4) | (buf[3] >> 4);
    temp_raw = (((uint32_t)buf[3] & 0x0F) << 16) | ((uint32_t)buf[4] << 8) | buf[5];

    data->Humidity    = (float)hum_raw  / 1048576.0f * 100.0f;      /* 2^20 */
    data->Temperature = (float)temp_raw / 1048576.0f * 200.0f - 50.0f;

    return 0;
}
