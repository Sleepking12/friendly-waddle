﻿#ifndef __AHT20_H
#define __AHT20_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

/* AHT20 的 I2C 地址：7 位 0x38，左移一位 = 0x70 */
#define AHT20_I2C_ADDR      0x70

typedef struct
{
    float Temperature;      /* 温度，单位 ℃ */
    float Humidity;         /* 相对湿度，单位 %RH */
} AHT20_DataTypeDef;

uint8_t AHT20_Init(void);                       /* 返回 0 = 成功 */
uint8_t AHT20_Read(AHT20_DataTypeDef *data);    /* 返回 0 = 成功 */

#ifdef __cplusplus
}
#endif

#endif /* __AHT20_H */
