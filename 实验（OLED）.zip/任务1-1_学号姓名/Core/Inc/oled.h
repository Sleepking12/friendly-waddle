﻿#ifndef __OLED_H
#define __OLED_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

/*==================== 硬件连接（软件 I2C）====================
 *
 *   OLED        STM32
 *    VCC   ────  3.3V
 *    GND   ────  GND
 *    SCL   ────  PB6      ← 可改
 *    SDA   ────  PB7      ← 可改
 *
 * 注意：PB6/PB7 也是 I2C1 的默认引脚，接线和硬件 I2C 完全一样，
 *       但这里用 GPIO 软件模拟，原因见报告（仿真器能看到波形）。
 *============================================================*/
#define OLED_SCL_PORT       GPIOB
#define OLED_SCL_PIN        GPIO_PIN_6
#define OLED_SDA_PORT       GPIOB
#define OLED_SDA_PIN        GPIO_PIN_7

#define OLED_SCL_H()        HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_SET)
#define OLED_SCL_L()        HAL_GPIO_WritePin(OLED_SCL_PORT, OLED_SCL_PIN, GPIO_PIN_RESET)
#define OLED_SDA_H()        HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_SET)
#define OLED_SDA_L()        HAL_GPIO_WritePin(OLED_SDA_PORT, OLED_SDA_PIN, GPIO_PIN_RESET)
#define OLED_SDA_READ()     HAL_GPIO_ReadPin(OLED_SDA_PORT, OLED_SDA_PIN)

/*==================== 屏幕参数 ====================*/
#define OLED_WIDTH          128
#define OLED_HEIGHT         64
#define OLED_PAGES          (OLED_HEIGHT / 8)       /* 8 页 */

/*==================== 颜色 ====================*/
#define OLED_COLOR_BLACK    0
#define OLED_COLOR_WHITE    1

/*==================== 基础接口 ====================*/
void OLED_Init(void);
void OLED_ClearBuffer(void);
void OLED_FillBuffer(void);
void OLED_Refresh(void);                            /* 刷整屏 */
void OLED_RefreshRange(uint8_t pageStart, uint8_t pageEnd);  /* 只刷指定页 */
void OLED_Clear(void);                              /* 清屏并刷新 */

/*==================== 绘图接口 ====================*/
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t color);
void OLED_DrawLine(int x1, int y1, int x2, int y2, uint8_t color);
void OLED_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color);
void OLED_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color);

/*==================== 字符/汉字接口 ====================*/
void OLED_ShowChar(uint8_t x, uint8_t y, char ch);              /* ASCII 8x16 */
void OLED_ShowString(uint8_t x, uint8_t y, const char *str);    /* ASCII 字符串 */
void OLED_ShowChinese(uint8_t x, uint8_t y, int index);         /* 汉字 16x16 */
void OLED_ShowCNString(uint8_t x, uint8_t y, const char *str);  /* UTF-8 汉字串 */
void OLED_ShowNum(uint8_t x, uint8_t y, int32_t num, uint8_t len);
void OLED_ShowFloat(uint8_t x, uint8_t y, float val, uint8_t intLen, uint8_t decLen);

/*==================== 硬件滚动（SSD1306 内部滚动，不占 CPU）====================*/
void OLED_ScrollRight(uint8_t startPage, uint8_t endPage, uint8_t interval);
void OLED_ScrollLeft(uint8_t startPage, uint8_t endPage, uint8_t interval);
void OLED_ScrollUp(uint8_t startPage, uint8_t endPage, uint8_t interval);
void OLED_ScrollDown(uint8_t startPage, uint8_t endPage, uint8_t interval);
void OLED_ScrollStop(void);

/*==================== 显存（外部可访问，用于自己画图）====================*/
extern uint8_t OLED_Buf[OLED_PAGES][OLED_WIDTH];

#ifdef __cplusplus
}
#endif

#endif /* __OLED_H */
