

#include "stm32f1xx_hal.h"
#include "oled.h"
#include "oledfont.h"
#include <string.h>

void Error_Handler(void);

/*==================== 长字符串 ====================*/
#define SCROLL_TEXT     "Hello，欢迎来到重庆交通大学物联网实训室！"

/*==================== 宽缓冲区宽度（软件滑动用）====================*/
#define SCROLL_BUF_W    384


#define SCROLL_STEP     2
#define SCROLL_DELAY    0

/*==============================================================================
 * 系统时钟：HSI 8MHz
 *============================================================================*/
void SystemClock_Config(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) { ; }

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_HSI;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { ; }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) { ; }
}

/*==============================================================================
 * ★ 中断服务函数（HAL 库必需）
 *============================================================================*/
void SysTick_Handler(void)    { HAL_IncTick(); }
void NMI_Handler(void)        { while (1) { ; } }
void HardFault_Handler(void)  { while (1) { ; } }
void MemManage_Handler(void)  { while (1) { ; } }
void BusFault_Handler(void)   { while (1) { ; } }
void UsageFault_Handler(void) { while (1) { ; } }
void SVC_Handler(void)        { ; }
void DebugMon_Handler(void)   { ; }
void PendSV_Handler(void)     { ; }

/*==============================================================================
 * 宽缓冲区（2 页高 = 16 像素，384 列）
 *   384 列 × 2 页 = 768 字节 RAM
 *============================================================================*/
static uint8_t g_Buf[2][SCROLL_BUF_W];

/*---- 清空宽缓冲区 ----*/
static void Buf_Clear(void)
{
    memset(g_Buf, 0x00, sizeof(g_Buf));
}

/*---- 往宽缓冲区画 ASCII（8x16）----*/
static void Buf_DrawChar(int x, char ch)
{
    int page, col;

    if (ch < 32 || ch > 126) { ch = ' '; }

    for (page = 0; page < 2; page++)
    {
        for (col = 0; col < 8; col++)
        {
            if ((x + col) >= 0 && (x + col) < SCROLL_BUF_W)
            {
                g_Buf[page][x + col] = F6x8_ASCII[ch - 32][page * 8 + col];
            }
        }
    }
}

/*---- 往宽缓冲区画汉字（16x16）----*/
static void Buf_DrawCN(int x, int index)
{
    int page, col;

    if (index < 0 || index >= OLED_CN_COUNT) { return; }

    for (page = 0; page < 2; page++)
    {
        for (col = 0; col < 16; col++)
        {
            if ((x + col) >= 0 && (x + col) < SCROLL_BUF_W)
            {
                g_Buf[page][x + col] = F16x16_CN[index][page * 16 + col];
            }
        }
    }
}

/*---- 把 UTF-8 字符串画进宽缓冲区，返回占用宽度 ----*/
static int Buf_DrawString(int x, const char *str)
{
    int idx;

    while (*str != 0)
    {
        if ((uint8_t)*str >= 0x80)          /* 汉字（UTF-8 3 字节）*/
        {
            idx = OLED_FindChinese(str);
            Buf_DrawCN(x, idx);
            x += 16;
            str += 3;
        }
        else                                /* ASCII */
        {
            Buf_DrawChar(x, *str);
            x += 8;
            str += 1;
        }

        if (x >= SCROLL_BUF_W) { break; }
    }

    return x;
}


static void Buf_ShowWindow(int offset, uint8_t y)
{
    int col;

    for (col = 0; col < OLED_WIDTH; col++)
    {
        if ((offset + col) < SCROLL_BUF_W)
        {
            OLED_Buf[y / 8 + 0][col] = g_Buf[0][offset + col];
            OLED_Buf[y / 8 + 1][col] = g_Buf[1][offset + col];
        }
        else
        {
            OLED_Buf[y / 8 + 0][col] = 0x00;
            OLED_Buf[y / 8 + 1][col] = 0x00;
        }
    }
}

/*==============================================================================
 * ① 软件逐像素左滑
 *============================================================================*/
static void Demo_SoftScroll(void)
{
    int contentW;
    int offset;
    int maxOffset;

    /* 把长字符串画进宽缓冲区 */
    Buf_Clear();
    contentW = Buf_DrawString(0, SCROLL_TEXT);

    maxOffset = contentW - OLED_WIDTH;
    if (maxOffset < 0) { maxOffset = 0; }

    /* 整屏先清一次（因为后面只刷局部，其他页要保持干净）*/
    OLED_ClearBuffer();
    OLED_Refresh();

    /* 从右往左滑动
     * 关键优化：文字只占第 3、4 页（y=24 → 页 3~4）
     *   所以每帧只刷这 2 页（256 字节），不用刷整屏 1024 字节
     *   → 刷新时间从约 38ms 降到约 10ms，快 4 倍
     */
    for (offset = 0; offset <= maxOffset; offset += SCROLL_STEP)
    {
        Buf_ShowWindow(offset, 24);         /* 只改第 3、4 页的显存 */
        OLED_RefreshRange(3, 4);            /* 只把这 2 页发到屏幕 */

        /* 每帧移 SCROLL_STEP 像素：2 像素/帧 → 又翻一倍速度 */
        HAL_Delay(SCROLL_DELAY);
    }

    HAL_Delay(600);
}

/*==============================================================================
 * ② 硬件水平滚动（SSD1306 内部滚动命令）
 *============================================================================*/
static void Demo_HardScrollH(void)
{
    OLED_ClearBuffer();
    OLED_ShowCNString(0,  0, "重庆交通大学");
    OLED_ShowCNString(0, 16, "物联网实训室");
    OLED_ShowCNString(0, 32, "欢迎来到");
    OLED_ShowString(0, 48, "HARDWARE SCROLL");
    OLED_Refresh();

    HAL_Delay(1500);

    /* 启动硬件向左滚动，滚 6 秒
     * 间隔参数：4=3帧/步（最快）  0=5帧/步（快）
     *           2=128帧/步（最慢，别用）
     */
    OLED_ScrollLeft(0, 7, 4);
    HAL_Delay(6000);
    OLED_ScrollStop();

    HAL_Delay(800);

    /* 再向右滚 6 秒 */
    OLED_ScrollRight(0, 7, 4);
    HAL_Delay(6000);
    OLED_ScrollStop();

    /* 滚动会打乱显存内容，这里清屏恢复正常状态 */
    OLED_ClearBuffer();
    OLED_Refresh();

    HAL_Delay(500);
}

/*==============================================================================
 * 主函数
 *============================================================================*/
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    OLED_Init();
    OLED_Clear();

    /*---- 开机画面 ----*/
    OLED_ShowCNString(16, 8, "欢迎来到");
    OLED_ShowCNString(0, 40, "重庆交通大学");
    OLED_Refresh();
    HAL_Delay(1500);

    while (1)
    {
        Demo_SoftScroll();      /* ① 软件逐像素左滑（长字符串）*/
        Demo_HardScrollH();     /* ② 硬件水平滚动 */
    }
}
