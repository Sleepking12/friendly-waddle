﻿/*******************************************************************************
 * 文件名：oled.c
 * 功能  ：0.96 寸 OLED（SSD1306，128x64，I2C 接口）驱动
 * 说明  ：I2C 采用 **GPIO 软件模拟**，不占用硬件 I2C 外设
 *
 * ============================ 为什么用软件 I2C ============================
 *   ① 不依赖硬件 I2C 外设，任何引脚都能用，移植方便
 *   ② 引脚是普通 GPIO，**Keil 逻辑分析仪能看到 SDA/SCL 的波形**
 *      （硬件 I2C 的引脚是复用功能，仿真器读不到，见报告）
 *   ③ 时序完全可控，便于理解 I2C 协议
 *
 * ============================ SSD1306 的 I2C 地址 ============================
 *   7 位地址 0x3C，左移一位加写标志 = 0x78
 *   每个字节：1 个控制字节（0x00=命令，0x40=数据）+ 1 个数据字节
 ******************************************************************************/

#include "oled.h"
#include "oledfont.h"
#include <string.h>

/*==================== SSD1306 地址与命令 ====================*/
#define OLED_I2C_ADDR       0x78        /* 0x3C << 1 */

#define OLED_CMD            0x00        /* 控制字节：后面是命令 */
#define OLED_DATA           0x40        /* 控制字节：后面是数据 */

/*==================== 显存 ====================*/
uint8_t OLED_Buf[OLED_PAGES][OLED_WIDTH];

/*==============================================================================
 * ============================ 软件 I2C 底层 ============================
 *============================================================================*/

/*---- 微秒级延时 ----
 * 8MHz 下，一次循环约 0.5us，循环 4 次约 2us
 * I2C 标准模式 100kHz，周期 10us；这里给足时间，稳定优先
 */
static void IIC_Delay(void)
{
    /* 定长 __NOP()：每个 NOP 1 个时钟周期，12 个 = 12 周期 = 1.5us（8MHz）
     * 每个 I2C 位 3 次延时 ≈ 4.5us → 约 220kHz
     *
     * ★ 比 for 循环快得多：循环有 volatile 读写 + 比较 + 跳转，每次约 8 周期
     *
     * 想更快：把 12 改成 8（约 330kHz）
     * 出现花屏/乱码：把 12 改成 16 或 20
     */
    __NOP(); __NOP(); __NOP(); __NOP();
    __NOP(); __NOP(); __NOP(); __NOP();
    __NOP(); __NOP(); __NOP(); __NOP();
}

/*---- 起始信号：SCL 高时，SDA 由高变低 ----*/
static void IIC_Start(void)
{
    OLED_SDA_H();
    OLED_SCL_H();
    IIC_Delay();
    OLED_SDA_L();       /* ★ 关键：SCL 高电平期间 SDA 下降沿 = 起始 */
    IIC_Delay();
    OLED_SCL_L();
    IIC_Delay();
}

/*---- 停止信号：SCL 高时，SDA 由低变高 ----*/
static void IIC_Stop(void)
{
    OLED_SDA_L();
    OLED_SCL_H();
    IIC_Delay();
    OLED_SDA_H();       /* ★ 关键：SCL 高电平期间 SDA 上升沿 = 停止 */
    IIC_Delay();
}

/*---- 等待从机应答 ----
 * 返回 0 = 收到应答（ACK），1 = 无应答（NACK）
 */
static uint8_t IIC_WaitAck(void)
{
    uint8_t ret;

    OLED_SDA_H();       /* 释放 SDA，由从机拉低 */
    IIC_Delay();
    OLED_SCL_H();
    IIC_Delay();

    ret = (OLED_SDA_READ() == GPIO_PIN_SET) ? 1 : 0;   /* 低电平 = 应答 */

    OLED_SCL_L();
    IIC_Delay();
    return ret;
}

/*---- 发送一个字节（高位先发）----*/
static void IIC_SendByte(uint8_t dat)
{
    uint8_t i;

    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80) { OLED_SDA_H(); }
        else            { OLED_SDA_L(); }

        dat <<= 1;
        IIC_Delay();

        OLED_SCL_H();   /* SCL 高电平期间 SDA 必须稳定 */
        IIC_Delay();
        OLED_SCL_L();
        IIC_Delay();
    }

    IIC_WaitAck();
}

/*---- 写一个字节到 OLED ----*/
static void OLED_WriteByte(uint8_t ctrl, uint8_t dat)
{
    IIC_Start();
    IIC_SendByte(OLED_I2C_ADDR);    /* 从机地址 + 写 */
    IIC_SendByte(ctrl);             /* 控制字节：0x00 命令 / 0x40 数据 */
    IIC_SendByte(dat);              /* 实际内容 */
    IIC_Stop();
}

/*---- 写命令 ----*/
static void OLED_WriteCmd(uint8_t cmd)
{
    OLED_WriteByte(OLED_CMD, cmd);
}

/* 注意：OLED_Refresh() 里直接调用 IIC_SendByte 连发数据，
 * 不再需要单字节的 OLED_WriteData()
 */

/*==============================================================================
 * ============================ 初始化 ============================
 *============================================================================*/
void OLED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /*---- 打开 GPIOB 时钟 ----*/
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /*---- SCL / SDA 配置成开漏输出 ----
     * I2C 总线要求开漏（Open Drain）+ 上拉，
     * OLED 模块上一般自带 4.7k 上拉电阻
     */
    OLED_SCL_H();
    OLED_SDA_H();

    GPIO_InitStruct.Pin   = OLED_SCL_PIN | OLED_SDA_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;    /* 开漏输出 */
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    OLED_SCL_H();
    OLED_SDA_H();
    HAL_Delay(100);             /* 等屏上电稳定 */

    /*---- SSD1306 初始化序列 ----*/
    OLED_WriteCmd(0xAE);        /* 关显示 */
    OLED_WriteCmd(0x20);        /* 设置内存寻址模式 */
    OLED_WriteCmd(0x00);        /*   水平寻址 */
    OLED_WriteCmd(0xB0);        /* 页地址 = 0 */
    OLED_WriteCmd(0xC8);        /* COM 扫描方向：从下到上 */
    OLED_WriteCmd(0x00);        /* 列低地址 */
    OLED_WriteCmd(0x10);        /* 列高地址 */
    OLED_WriteCmd(0x40);        /* 起始行 = 0 */
    OLED_WriteCmd(0x81);        /* 对比度 */
    OLED_WriteCmd(0xFF);        /*   最亮 */
    OLED_WriteCmd(0xA1);        /* 段重映射：左右方向 */
    OLED_WriteCmd(0xA6);        /* 正常显示（非反色）*/
    OLED_WriteCmd(0xA8);        /* 多路复用率 */
    OLED_WriteCmd(0x3F);        /*   1/64 */
    OLED_WriteCmd(0xA4);        /* 输出跟随显存 */
    OLED_WriteCmd(0xD3);        /* 显示偏移 */
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xD5);        /* 设置时钟分频比 / 振荡频率 */
    /* ★ 参数含义（很容易搞反）：
     *     高 4 位 D = 分频比：0 = 不分频（最快），15 = 16 分频（最慢）
     *     低 4 位 F = 振荡频率：0 = 最低，8 = 默认，15 = 最高
     *
     *   0xF0 → D=15、F=0 → 最慢（帧频十几 Hz，滚动极慢）
     *   0x80 → D=8 、F=0 → **常用默认值，稳定**（本实验用这个）
     *   0x0F → D=0 、F=15 → 最快，但**帧率过高会出现闪烁/变暗**
     *
     * 实测：0x0F 时屏幕明显闪烁，所以改用 0x80。
     * 想要滚动再快一些，可以试 0xA0 或 0xC0 折中。
     */
    OLED_WriteCmd(0x80);
    OLED_WriteCmd(0xD9);        /* 预充电周期 */
    OLED_WriteCmd(0x22);
    OLED_WriteCmd(0xDA);        /* COM 引脚硬件配置 */
    OLED_WriteCmd(0x12);
    OLED_WriteCmd(0xDB);        /* VCOMH */
    OLED_WriteCmd(0x20);
    OLED_WriteCmd(0x8D);        /* 电荷泵 */
    OLED_WriteCmd(0x14);        /*   打开 */
    OLED_WriteCmd(0xAF);        /* 开显示 */

    OLED_ClearBuffer();
    OLED_Refresh();
}

/*==============================================================================
 * ============================ 显存操作 ============================
 *============================================================================*/
void OLED_ClearBuffer(void)
{
    memset(OLED_Buf, 0x00, sizeof(OLED_Buf));
}

void OLED_FillBuffer(void)
{
    memset(OLED_Buf, 0xFF, sizeof(OLED_Buf));
}

/*---- 把显存整体刷到屏幕 ----*/
void OLED_RefreshRange(uint8_t pageStart, uint8_t pageEnd)
{
    uint8_t page, col;

    if (pageStart > (OLED_PAGES - 1)) { pageStart = OLED_PAGES - 1; }
    if (pageEnd   > (OLED_PAGES - 1)) { pageEnd   = OLED_PAGES - 1; }
    if (pageStart > pageEnd) { return; }

    for (page = pageStart; page <= pageEnd; page++)
    {
        OLED_WriteCmd((uint8_t)(0xB0 + page));  /* 设置页地址 */
        OLED_WriteCmd(0x00);                    /* 列低 4 位 */
        OLED_WriteCmd(0x10);                    /* 列高 4 位 */

        /* ★ 关键优化：整页 128 字节**一次性连发**
         * SSD1306 写数据后列指针会自动 +1，
         * 所以不用每字节都重新 起始/停止，可以把 128 字节连在一起发。
         *
         * 原来：每字节一次 I2C 事务 → 每屏 1048 次事务
         * 现在：每页一次 I2C 事务 → 每屏 8 次数据事务
         * 速度提升约 10 倍
         */
        IIC_Start();
        IIC_SendByte(OLED_I2C_ADDR);
        IIC_SendByte(OLED_DATA);
        for (col = 0; col < OLED_WIDTH; col++)
        {
            IIC_SendByte(OLED_Buf[page][col]);
        }
        IIC_Stop();
    }
}

/*---- 刷整屏（调用局部刷新，0~7 页）----*/
void OLED_Refresh(void)
{
    OLED_RefreshRange(0, OLED_PAGES - 1);
}

void OLED_Clear(void)
{
    OLED_ClearBuffer();
    OLED_Refresh();
}

/*==============================================================================
 * ============================ 绘图 ============================
 *============================================================================*/
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t color)
{
    if (x >= OLED_WIDTH || y >= OLED_HEIGHT) { return; }

    if (color == OLED_COLOR_WHITE)
    {
        OLED_Buf[y / 8][x] |=  (uint8_t)(1U << (y % 8));
    }
    else
    {
        OLED_Buf[y / 8][x] &= (uint8_t)~(1U << (y % 8));
    }
}

void OLED_DrawLine(int x1, int y1, int x2, int y2, uint8_t color)
{
    int dx = (x2 > x1) ? (x2 - x1) : (x1 - x2);
    int dy = (y2 > y1) ? (y2 - y1) : (y1 - y2);
    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;

    while (1)
    {
        OLED_DrawPoint((uint8_t)x1, (uint8_t)y1, color);
        if (x1 == x2 && y1 == y2) { break; }

        {
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 <  dx) { err += dx; y1 += sy; }
        }
    }
}

void OLED_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color)
{
    OLED_DrawLine(x, y, x + w - 1, y, color);
    OLED_DrawLine(x, y + h - 1, x + w - 1, y + h - 1, color);
    OLED_DrawLine(x, y, x, y + h - 1, color);
    OLED_DrawLine(x + w - 1, y, x + w - 1, y + h - 1, color);
}

void OLED_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color)
{
    uint8_t i, j;

    for (i = 0; i < w; i++)
    {
        for (j = 0; j < h; j++)
        {
            OLED_DrawPoint((uint8_t)(x + i), (uint8_t)(y + j), color);
        }
    }
}

/*==============================================================================
 * ============================ 字符与汉字 ============================
 *============================================================================*/
void OLED_ShowChar(uint8_t x, uint8_t y, char ch)
{
    uint8_t page, col, dat;

    if (ch < 32 || ch > 126) { ch = ' '; }
    if (x > OLED_WIDTH - 8 || y > OLED_HEIGHT - 16) { return; }

    for (page = 0; page < 2; page++)            /* 8x16 占 2 页 */
    {
        for (col = 0; col < 8; col++)
        {
            dat = F6x8_ASCII[ch - 32][page * 8 + col];
            OLED_Buf[y / 8 + page][x + col] = dat;
        }
    }
}

void OLED_ShowString(uint8_t x, uint8_t y, const char *str)
{
    while (*str != 0)
    {
        OLED_ShowChar(x, y, *str);
        x += 8;
        if (x > OLED_WIDTH - 8) { break; }
        str++;
    }
}

void OLED_ShowChinese(uint8_t x, uint8_t y, int index)
{
    uint8_t page, col, dat;

    if (index < 0 || index >= OLED_CN_COUNT) { return; }
    if (x > OLED_WIDTH - 16 || y > OLED_HEIGHT - 16) { return; }

    for (page = 0; page < 2; page++)            /* 16x16 占 2 页 */
    {
        for (col = 0; col < 16; col++)
        {
            dat = F16x16_CN[index][page * 16 + col];
            OLED_Buf[y / 8 + page][x + col] = dat;
        }
    }
}

/*---- 显示 UTF-8 汉字串（每个汉字 3 字节）----*/
void OLED_ShowCNString(uint8_t x, uint8_t y, const char *str)
{
    int idx;

    while (*str != 0)
    {
        if ((uint8_t)*str >= 0x80)          /* 高位置 1 = 汉字（UTF-8 3 字节）*/
        {
            idx = OLED_FindChinese(str);
            if (idx >= 0)
            {
                OLED_ShowChinese(x, y, idx);
            }
            x += 16;
            str += 3;
        }
        else                                /* ASCII */
        {
            OLED_ShowChar(x, y, *str);
            x += 8;
            str += 1;
        }

        if (x > OLED_WIDTH - 8) { break; }
    }
}

void OLED_ShowNum(uint8_t x, uint8_t y, int32_t num, uint8_t len)
{
    uint8_t i;
    uint8_t start = x;

    if (num < 0)
    {
        OLED_ShowChar(start, y, '-');
        start += 8;
        num = -num;
    }

    for (i = 0; i < len; i++)
    {
        OLED_ShowChar((uint8_t)(start + (len - 1 - i) * 8), y,
                      (char)('0' + (num % 10)));
        num /= 10;
    }
}

void OLED_ShowFloat(uint8_t x, uint8_t y, float val, uint8_t intLen, uint8_t decLen)
{
    uint8_t i;
    int32_t v = (int32_t)(val * 100.0f + 0.5f);     /* 保留 2 位小数 */

    OLED_ShowNum(x, y, v / 100, intLen);
    x += intLen * 8;

    OLED_ShowChar(x, y, '.');
    x += 8;

    for (i = 0; i < decLen; i++)
    {
        OLED_ShowChar((uint8_t)(x + i * 8), y, (char)('0' + ((v / (decLen == 2 ? (i == 0 ? 10 : 1) : 1)) % 10)));
    }

    /* 上面的通用写法太绕，实际只支持 2 位小数 */
    if (decLen == 2)
    {
        OLED_ShowChar((uint8_t)(x),     y, (char)('0' + ((v / 10) % 10)));
        OLED_ShowChar((uint8_t)(x + 8), y, (char)('0' + (v % 10)));
    }
}

/*==============================================================================
 * ============================ 硬件滚动 ============================
 *
 *  SSD1306 内部可以自己滚动显存，不需要 MCU 重画 —— 即"硬件刷屏模式"
 *  优点：几乎不占 CPU，滚动流畅
 *  缺点：只能整页滚动，不能任意像素
 *============================================================================*/

/*---- 水平滚动（向右）----
 * startPage/endPage：参与滚动的页范围（0~7）
 * interval        ：滚动间隔，**不是越小越快**！对应关系：
 *
 *      值  每步经过的帧数   速度
 *      --  --------------   ----
 *      0        5           快  ★
 *      1       64           慢
 *      2      128           最慢（默认别用）
 *      3      256           最慢
 *      4        3           最快 ★★
 *      5        4           快
 *      6        5           快
 *      7       25           中
 *
 *   （SSD1306 内部帧频约 105Hz，5 帧/步 ≈ 48ms 走一列）
 */
void OLED_ScrollRight(uint8_t startPage, uint8_t endPage, uint8_t interval)
{
    OLED_WriteCmd(0x2E);            /* 先关闭滚动 */
    OLED_WriteCmd(0x26);            /* 水平向右滚动 */
    OLED_WriteCmd(0x00);            /* 虚拟字节 */
    OLED_WriteCmd(startPage);       /* 起始页 */
    OLED_WriteCmd(interval);        /* 滚动间隔 */
    OLED_WriteCmd(endPage);         /* 结束页 */
    OLED_WriteCmd(0x00);            /* 虚拟字节 */
    OLED_WriteCmd(0xFF);            /* 虚拟字节 */
    OLED_WriteCmd(0x2F);            /* 启动滚动 */
}

/*---- 水平滚动（向左）----*/
void OLED_ScrollLeft(uint8_t startPage, uint8_t endPage, uint8_t interval)
{
    OLED_WriteCmd(0x2E);
    OLED_WriteCmd(0x27);            /* 水平向左滚动 */
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(startPage);
    OLED_WriteCmd(interval);
    OLED_WriteCmd(endPage);
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xFF);
    OLED_WriteCmd(0x2F);
}

/*---- 垂直+水平滚动（向上）----*/
void OLED_ScrollUp(uint8_t startPage, uint8_t endPage, uint8_t interval)
{
    OLED_WriteCmd(0x2E);
    OLED_WriteCmd(0x29);            /* 垂直+水平 */
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(startPage);
    OLED_WriteCmd(interval);
    OLED_WriteCmd(endPage);
    OLED_WriteCmd(0x01);            /* 垂直偏移（1 行）*/
    OLED_WriteCmd(0x2F);
}

/*---- 垂直+水平滚动（向下）----*/
void OLED_ScrollDown(uint8_t startPage, uint8_t endPage, uint8_t interval)
{
    OLED_WriteCmd(0x2E);
    OLED_WriteCmd(0x2A);            /* 垂直+水平 */
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(startPage);
    OLED_WriteCmd(interval);
    OLED_WriteCmd(endPage);
    OLED_WriteCmd(0x01);
    OLED_WriteCmd(0x2F);
}

/*---- 停止滚动 ----*/
void OLED_ScrollStop(void)
{
    OLED_WriteCmd(0x2E);
}
